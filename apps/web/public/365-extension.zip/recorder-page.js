// src/recorder/recorder-page.ts
var state = null;
var startedAt = 0;
var timerInterval = null;
var lastShareUrl = "";
var intentionalStop = false;
var tabAudioLost = false;
var TAB_AUDIO_LOST_MSG = "\u26A0\uFE0F Mijoz ovozi uzildi \u2014 yozuv to'xtatildi va qisman saqlanmoqda.";
function handleTabAudioLoss() {
  if (intentionalStop || tabAudioLost) return;
  tabAudioLost = true;
  if (state && state.recorder.state !== "inactive") {
    state.recorder.stop();
  }
  sendMsg({ type: "TAB_AUDIO_LOST" });
  const warn = $("rec-audio-warn");
  if (warn) {
    warn.textContent = TAB_AUDIO_LOST_MSG;
    warn.classList.remove("hidden");
  }
}
var VIEWS = [
  "view-idle",
  "view-recording",
  "view-uploading",
  "view-complete",
  "view-error"
];
function showView(id) {
  for (const v of VIEWS) {
    const el = document.getElementById(v);
    if (el) el.classList.toggle("hidden", v !== id);
  }
}
function $(id) {
  return document.getElementById(id);
}
function setIdleMsg(text, isError) {
  const el = $("idle-msg");
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("msg-error", isError);
}
function sendMsg(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
  });
}
function sendMsgAwait(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}
function formatElapsed(ms) {
  const totalSec = Math.floor(ms / 1e3);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor(totalSec % 3600 / 60);
  const s = totalSec % 60;
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
function startTimer() {
  stopTimer();
  startedAt = Date.now();
  const el = $("timer");
  if (el) el.textContent = "00:00";
  timerInterval = setInterval(() => {
    const t = $("timer");
    if (t) t.textContent = formatElapsed(Date.now() - startedAt);
  }, 1e3);
}
function stopTimer() {
  if (timerInterval !== null) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}
function pickMimeType() {
  const candidates = [
    "video/mp4;codecs=h264",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return "video/webm";
}
function cleanup(s) {
  for (const t of s.displayStream.getTracks()) t.stop();
  if (s.micStream) for (const t of s.micStream.getTracks()) t.stop();
  if (s.tabAudioStream) for (const t of s.tabAudioStream.getTracks()) t.stop();
  s.audioCtx.close().catch(() => {
  });
}
async function getSettings() {
  const resp = await sendMsgAwait({ type: "GET_ALL_SETTINGS" });
  return {
    micEnabled: resp?.micEnabled !== false,
    micDeviceId: typeof resp?.micDeviceId === "string" ? resp.micDeviceId : ""
  };
}
var TAB_AUDIO_UNAVAILABLE_MSG = "Mijoz ovozini ulab bo'lmadi \u2014 Meet tabini yangilab, qaytadan boshlang.";
function failClosedStart(message, streams, startBtn) {
  for (const t of streams.displayStream.getTracks()) t.stop();
  if (streams.micStream) for (const t of streams.micStream.getTracks()) t.stop();
  if (streams.tabAudioStream) {
    for (const t of streams.tabAudioStream.getTracks()) t.stop();
  }
  streams.audioCtx?.close().catch(() => {
  });
  sendMsg({ type: "INSTRUCTION_CANCEL" });
  const el = $("error-msg");
  if (el) el.textContent = message;
  showView("view-error");
  if (startBtn) startBtn.disabled = false;
}
async function startRecording() {
  setIdleMsg("", false);
  const startBtn = $("btn-start");
  if (startBtn) startBtn.disabled = true;
  intentionalStop = false;
  tabAudioLost = false;
  const settings = await getSettings();
  let displayStream;
  try {
    displayStream = await navigator.mediaDevices.getDisplayMedia({
      video: {
        width: { max: 1280 },
        height: { max: 720 },
        frameRate: { max: 24 }
      },
      audio: true
    });
  } catch (err) {
    sendMsg({ type: "INSTRUCTION_CANCEL" });
    const name = err instanceof Error ? err.name : "";
    const friendly = name === "NotAllowedError" ? "Screen sharing was cancelled. Click the button to try again." : `Couldn't start screen capture: ${err instanceof Error ? err.message : String(err)}`;
    setIdleMsg(friendly, true);
    if (startBtn) startBtn.disabled = false;
    return;
  }
  try {
    let micStream = null;
    if (settings.micEnabled && settings.micDeviceId) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: { deviceId: { exact: settings.micDeviceId } }
        });
      } catch {
        try {
          micStream = await navigator.mediaDevices.getUserMedia({
            audio: true
          });
        } catch {
          micStream = null;
        }
      }
    } else if (settings.micEnabled) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch {
        micStream = null;
      }
    }
    let tabAudioStream = null;
    let meetingRequired = false;
    try {
      const resp = await sendMsgAwait({ type: "REQUEST_TAB_AUDIO" });
      meetingRequired = resp?.required === true;
      const streamId = resp?.streamId;
      if (streamId) {
        try {
          tabAudioStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              mandatory: {
                chromeMediaSource: "tab",
                chromeMediaSourceId: streamId
              }
            },
            video: false
          });
        } catch {
          tabAudioStream = null;
        }
      }
    } catch {
      tabAudioStream = null;
    }
    const haveTabAudio = !!tabAudioStream && tabAudioStream.getAudioTracks().length > 0;
    if (meetingRequired && !haveTabAudio) {
      failClosedStart(
        TAB_AUDIO_UNAVAILABLE_MSG,
        { displayStream, micStream, tabAudioStream },
        startBtn
      );
      return;
    }
    const audioCtx = new AudioContext({ sampleRate: 48e3 });
    const dest = audioCtx.createMediaStreamDestination();
    if (!haveTabAudio && displayStream.getAudioTracks().length > 0) {
      audioCtx.createMediaStreamSource(displayStream).connect(dest);
    }
    if (micStream && micStream.getAudioTracks().length > 0) {
      audioCtx.createMediaStreamSource(micStream).connect(dest);
    }
    if (haveTabAudio && tabAudioStream) {
      const tabSrc = audioCtx.createMediaStreamSource(tabAudioStream);
      tabSrc.connect(dest);
      tabSrc.connect(audioCtx.destination);
    }
    await audioCtx.resume();
    if (meetingRequired) {
      const tabTrack = tabAudioStream?.getAudioTracks()[0];
      const destTrack = dest.stream.getAudioTracks()[0];
      const liveOk = audioCtx.state === "running" && !!tabTrack && tabTrack.readyState === "live" && !tabTrack.muted && !!destTrack && destTrack.readyState === "live";
      if (!liveOk) {
        failClosedStart(
          TAB_AUDIO_UNAVAILABLE_MSG,
          { displayStream, micStream, tabAudioStream, audioCtx },
          startBtn
        );
        return;
      }
    }
    const recordStream = new MediaStream([
      ...displayStream.getVideoTracks(),
      ...dest.stream.getAudioTracks()
    ]);
    const mime = pickMimeType();
    const recorder = new MediaRecorder(recordStream, {
      mimeType: mime,
      videoBitsPerSecond: 6e5,
      audioBitsPerSecond: 96e3
    });
    let chunkIndex = 0;
    let pendingChunks = 0;
    let stopRequested = false;
    const finishStop = () => {
      if (state) {
        cleanup(state);
        state = null;
      }
      stopTimer();
      sendMsg({ type: "RECORDER_STOPPED" });
    };
    recorder.ondataavailable = async (e) => {
      if (e.data.size <= 0) {
        if (stopRequested && pendingChunks === 0) finishStop();
        return;
      }
      pendingChunks++;
      try {
        const buffer = await e.data.arrayBuffer();
        sendMsg({
          type: "RECORDER_CHUNK",
          chunk: Array.from(new Uint8Array(buffer)),
          index: chunkIndex++,
          mime: recorder.mimeType,
          ts: Date.now()
        });
      } finally {
        pendingChunks--;
        if (stopRequested && pendingChunks === 0) finishStop();
      }
    };
    recorder.onerror = () => {
      sendMsg({ type: "RECORDER_ERROR", error: "MediaRecorder error" });
      if (state) {
        cleanup(state);
        state = null;
      }
    };
    recorder.onstop = () => {
      stopRequested = true;
      if (pendingChunks === 0) finishStop();
    };
    const videoTracks = displayStream.getVideoTracks();
    if (videoTracks.length > 0) {
      videoTracks[0].onended = () => {
        if (state && state.recorder.state !== "inactive") {
          state.recorder.stop();
        }
      };
    }
    state = { recorder, audioCtx, displayStream, micStream, tabAudioStream };
    if (meetingRequired) {
      const tabTrack = tabAudioStream?.getAudioTracks()[0];
      if (tabTrack) {
        tabTrack.onended = () => handleTabAudioLoss();
        tabTrack.onmute = () => {
          setTimeout(() => {
            if (tabTrack.muted) handleTabAudioLoss();
          }, 1500);
        };
      }
      audioCtx.onstatechange = () => {
        if (state && audioCtx.state !== "running") handleTabAudioLoss();
      };
    }
    const startResp = await sendMsgAwait({
      type: "RECORDER_STARTED",
      mime,
      hasVideo: displayStream.getVideoTracks().length > 0,
      hasAudio: dest.stream.getAudioTracks().length > 0
    });
    if (!startResp?.ok) {
      cleanup(state);
      state = null;
      const reason = startResp?.error ?? "Couldn't start the upload session.";
      setIdleMsg(`Couldn't start recording: ${reason}`, true);
      showView("view-idle");
      if (startBtn) startBtn.disabled = false;
      return;
    }
    recorder.start(200);
    showView("view-recording");
    const audioWarn = $("rec-audio-warn");
    if (audioWarn) {
      const hasRemoteAudio = displayStream.getAudioTracks().length > 0 || (tabAudioStream?.getAudioTracks().length ?? 0) > 0;
      audioWarn.classList.toggle("hidden", hasRemoteAudio);
    }
    startTimer();
  } catch (err) {
    if (state) {
      cleanup(state);
      state = null;
    }
    sendMsg({
      type: "RECORDER_ERROR",
      error: err instanceof Error ? err.message : String(err)
    });
    setIdleMsg(
      `Couldn't start recording: ${err instanceof Error ? err.message : String(err)}`,
      true
    );
    showView("view-idle");
    if (startBtn) startBtn.disabled = false;
  }
}
function stopRecording() {
  intentionalStop = true;
  if (state && state.recorder.state !== "inactive") {
    state.recorder.stop();
  } else {
    stopTimer();
    sendMsg({ type: "RECORDER_STOPPED" });
  }
}
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function handleStateChange(s) {
  switch (s.kind) {
    case "uploading": {
      stopTimer();
      const pct = s.totalBytes && s.totalBytes > 0 ? Math.round((s.uploadedBytes ?? 0) / s.totalBytes * 100) : 0;
      const el = $("upload-progress");
      if (el) {
        el.textContent = `${formatBytes(s.uploadedBytes ?? 0)} uploaded (${pct}%)`;
      }
      showView("view-uploading");
      break;
    }
    case "finishing": {
      stopTimer();
      const el = $("upload-progress");
      if (el) el.textContent = "Finishing up\u2026";
      showView("view-uploading");
      break;
    }
    case "complete": {
      stopTimer();
      lastShareUrl = s.shareUrl ?? "";
      const el = $("complete-url");
      if (el) el.textContent = lastShareUrl;
      showView("view-complete");
      break;
    }
    case "error": {
      stopTimer();
      if (state) {
        if (state.recorder.state !== "inactive") {
          try {
            state.recorder.stop();
          } catch (_) {
          }
        }
        cleanup(state);
        state = null;
      }
      const el = $("error-msg");
      if (el) el.textContent = s.reason ?? "Unknown error";
      showView("view-error");
      break;
    }
    case "idle": {
      if (!state) {
        stopTimer();
        showView("view-idle");
        const startBtn = $("btn-start");
        if (startBtn) startBtn.disabled = false;
        setIdleMsg("", false);
      }
      break;
    }
  }
}
function wire() {
  $("btn-start")?.addEventListener("click", () => {
    startRecording().catch((err) => {
      setIdleMsg(
        `Couldn't start: ${err instanceof Error ? err.message : String(err)}`,
        true
      );
    });
  });
  $("btn-cancel")?.addEventListener("click", () => {
    window.close();
  });
  $("btn-stop")?.addEventListener("click", () => {
    const btn = $("btn-stop");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Finishing\u2026";
    }
    stopRecording();
  });
  $("btn-copy")?.addEventListener("click", () => {
    if (!lastShareUrl) return;
    navigator.clipboard.writeText(lastShareUrl).then(() => {
      const btn = $("btn-copy");
      if (btn) {
        btn.textContent = "Copied!";
        setTimeout(() => {
          btn.textContent = "Copy link";
        }, 2e3);
      }
    });
  });
  $("btn-open")?.addEventListener("click", () => {
    if (lastShareUrl) chrome.tabs.create({ url: lastShareUrl });
  });
  $("btn-close")?.addEventListener("click", () => {
    sendMsg({ type: "CANCEL" });
    window.close();
  });
  $("btn-retry")?.addEventListener("click", () => {
    sendMsg({ type: "RETRY" });
    showView("view-idle");
    const startBtn = $("btn-start");
    if (startBtn) startBtn.disabled = false;
    setIdleMsg("", false);
  });
  $("btn-close-err")?.addEventListener("click", () => {
    sendMsg({ type: "CANCEL" });
    window.close();
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (typeof message !== "object" || message === null) return;
    const msg = message;
    if (msg.type === "STATE_CHANGED") {
      const s = msg.state;
      if (s) handleStateChange(s);
    } else if (msg.type === "STOP_CAPTURE") {
      stopRecording();
      sendResponse({ ok: true });
    } else if (msg.type === "PAUSE_CAPTURE") {
      if (state && state.recorder.state === "recording") {
        state.recorder.pause();
      }
      sendResponse({ ok: true });
    } else if (msg.type === "RESUME_CAPTURE") {
      if (state && state.recorder.state === "paused") {
        state.recorder.resume();
      }
      sendResponse({ ok: true });
    } else if (msg.type === "TAB_AUDIO_LOST_REMOTE") {
      handleTabAudioLoss();
      sendResponse({ ok: true });
    }
  });
  window.addEventListener("beforeunload", () => {
    intentionalStop = true;
    if (state && state.recorder.state !== "inactive") {
      state.recorder.stop();
    } else if (!state) {
      sendMsg({ type: "INSTRUCTION_CANCEL" });
    }
  });
}
showView("view-idle");
wire();
//# sourceMappingURL=recorder-page.js.map
