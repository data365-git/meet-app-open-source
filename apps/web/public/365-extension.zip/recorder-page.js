// src/shared/capture-command.ts
var CAPTURE_COMMAND_PROBLEM = {
  PAUSE: "Couldn't pause \u2014 the recorder didn't respond. Still recording.",
  RESUME: "Couldn't resume \u2014 the recorder didn't respond. Still paused."
};
async function sendCaptureCommand(send, command) {
  let reply;
  try {
    reply = await send({ type: command });
  } catch {
    return { ok: false, error: CAPTURE_COMMAND_PROBLEM[command] };
  }
  const ok = typeof reply === "object" && reply !== null && reply.ok === true;
  return ok ? { ok: true } : { ok: false, error: CAPTURE_COMMAND_PROBLEM[command] };
}

// src/shared/client-audio.ts
function tabAudioStatus(track) {
  if (!track) return "missing";
  if (track.readyState !== "live") return "ended";
  if (track.muted) return "muted";
  return "live";
}
function isTabAudioLive(track) {
  return tabAudioStatus(track) === "live";
}

// src/shared/device-picker.ts
async function checkPermission(name) {
  try {
    const status = await navigator.permissions.query({ name });
    return status.state;
  } catch {
    return "prompt";
  }
}
async function populateDeviceSelect(select, kind, currentDeviceId, permissionConstraint) {
  const permName = kind === "audioinput" ? "microphone" : "camera";
  let permState = await checkPermission(permName);
  if (permState !== "granted") {
    try {
      const testStream = await navigator.mediaDevices.getUserMedia(permissionConstraint);
      for (const t of testStream.getTracks()) t.stop();
      permState = "granted";
    } catch {
      return "blocked";
    }
  }
  const devices = await navigator.mediaDevices.enumerateDevices();
  const filtered = devices.filter((d) => d.kind === kind);
  const defaultOpt = document.createElement("option");
  defaultOpt.value = "";
  defaultOpt.textContent = kind === "audioinput" ? "Default microphone" : "Default camera";
  select.appendChild(defaultOpt);
  for (const device of filtered) {
    const label = device.label || `${kind === "audioinput" ? "Mic" : "Camera"} ${device.deviceId.slice(0, 6)}`;
    const opt = document.createElement("option");
    opt.value = device.deviceId;
    opt.textContent = label;
    if (device.deviceId === currentDeviceId) opt.selected = true;
    select.appendChild(opt);
  }
  if (!currentDeviceId) select.value = "";
  return "granted";
}

// src/shared/recording-quality.ts
var VIDEO_BITS_PER_SECOND = 15e5;
var AUDIO_BITS_PER_SECOND = 128e3;

// src/recorder/recorder-page.ts
var _recorderUrlParams = new URLSearchParams(location.search);
var sourceTabIdParam = _recorderUrlParams.get("source");
var sourceTabId = sourceTabIdParam ? Number(sourceTabIdParam) : void 0;
var meetingRequiredParam = _recorderUrlParams.get("meeting") === "1";
var meetingIdParam = _recorderUrlParams.get("meetingId") ?? void 0;
var state = null;
var startedAt = 0;
var timerInterval = null;
var lastShareUrl = "";
var pausedAt = null;
var pausedAccumMs = 0;
var intentionalStop = false;
var clientAudioWaived = false;
var AUDIO_WARN_TEXT = {
  ended: "\u26A0\uFE0F Meet tab yopildi \u2014 qayta oching va extension'ni bosing, yoki yozuvni to'xtating.",
  muted: "\u26A0\uFE0F Mijoz ovozi o'chirilgan \u2014 Meet tab ovozini yoqing.",
  suspended: "\u26A0\uFE0F Mijoz ovozi vaqtincha uzildi \u2014 tiklanmoqda\u2026",
  waived: "\u26A0\uFE0F Mijoz ovozi olinmayapti \u2014 faqat ekran va mikrofon yozilmoqda.",
  "mic-only": "\u26A0\uFE0F System audio is NOT shared \u2014 other people's voices won't be recorded (only your mic). Stop, start again, and tick \u201CAlso share system audio\u201D in the picker."
};
var AUDIO_WARN_PRIORITY = {
  ended: 5,
  muted: 4,
  suspended: 3,
  waived: 2,
  "mic-only": 1
};
var activeAudioWarn = /* @__PURE__ */ new Set();
function renderAudioWarn() {
  const warn = $("rec-audio-warn");
  if (!warn) return;
  let top = null;
  for (const c of activeAudioWarn) {
    if (top === null || AUDIO_WARN_PRIORITY[c] > AUDIO_WARN_PRIORITY[top]) top = c;
  }
  if (top === null) {
    warn.classList.add("hidden");
    warn.textContent = "";
  } else {
    warn.textContent = AUDIO_WARN_TEXT[top];
    warn.classList.remove("hidden");
  }
}
function setAudioWarn(cause, active) {
  if (active) activeAudioWarn.add(cause);
  else activeAudioWarn.delete(cause);
  renderAudioWarn();
}
var degradedCauses = /* @__PURE__ */ new Set();
function handleTabAudioDegraded(cause) {
  if (intentionalStop || !state || state.recorder.state === "inactive") return;
  if (degradedCauses.has(cause)) return;
  degradedCauses.add(cause);
  setAudioWarn(cause, true);
  sendMsg({ type: "TAB_AUDIO_DEGRADED", cause });
}
function handleTabAudioRecovered(cause) {
  if (intentionalStop || cause === "ended" || !degradedCauses.has(cause)) return;
  degradedCauses.delete(cause);
  setAudioWarn(cause, false);
  if (degradedCauses.size === 0) sendMsg({ type: "TAB_AUDIO_RECOVERED" });
}
async function attemptAudioCtxResume(audioCtx) {
  try {
    await audioCtx.resume();
  } catch {
    return;
  }
  if (intentionalStop || !state || state.recorder.state === "inactive") return;
  if (audioCtx.state === "running") handleTabAudioRecovered("suspended");
}
var VIEWS = [
  "view-idle",
  "view-confirm",
  "view-recording",
  "view-uploading",
  "view-complete",
  "view-error"
];
function showView(id) {
  for (const v of VIEWS) {
    const el = document.getElementById(v);
    if (el) el.classList.toggle("hidden", v !== id);
  }
}
function $(id) {
  return document.getElementById(id);
}
function setIdleMsg(text, isError) {
  const el = $("idle-msg");
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("msg-error", isError);
}
function setCtlMsg(text) {
  const el = $("rec-ctl-msg");
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("hidden", text === "");
}
var controlInFlight = false;
function syncPauseLabel() {
  if (controlInFlight) return;
  const btn = $("btn-pause");
  if (!btn) return;
  btn.textContent = state?.recorder.state === "paused" ? "Resume" : "Pause";
  btn.disabled = false;
}
function sendMsg(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
  });
}
function sendMsgAwait(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}
function formatElapsed(ms) {
  const totalSec = Math.floor(ms / 1e3);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor(totalSec % 3600 / 60);
  const s = totalSec % 60;
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
function elapsedMs() {
  return Math.max(0, Date.now() - startedAt - pausedAccumMs);
}
function startTimer() {
  stopTimer();
  startedAt = Date.now();
  pausedAt = null;
  pausedAccumMs = 0;
  const el = $("timer");
  if (el) el.textContent = "00:00";
  setCtlMsg("");
  syncPauseLabel();
  timerInterval = setInterval(() => {
    const t = $("timer");
    if (t) t.textContent = formatElapsed(elapsedMs());
  }, 1e3);
}
function stopTimer() {
  if (timerInterval !== null) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}
function pauseTimer() {
  if (pausedAt !== null) return;
  pausedAt = Date.now();
  stopTimer();
  const t = $("timer");
  if (t) t.textContent = formatElapsed(elapsedMs());
}
function resumeTimer() {
  if (pausedAt === null) return;
  pausedAccumMs += Date.now() - pausedAt;
  pausedAt = null;
  timerInterval = setInterval(() => {
    const t = $("timer");
    if (t) t.textContent = formatElapsed(elapsedMs());
  }, 1e3);
}
function pickMimeType() {
  const candidates = [
    "video/mp4;codecs=h264",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return "video/webm";
}
function cleanup(s) {
  if (!s) return;
  for (const t of s.displayStream.getTracks()) t.stop();
  if (s.micStream) for (const t of s.micStream.getTracks()) t.stop();
  if (s.tabAudioStream) for (const t of s.tabAudioStream.getTracks()) t.stop();
  s.audioCtx.close().catch(() => {
  });
}
async function getSettings() {
  const resp = await sendMsgAwait({ type: "GET_ALL_SETTINGS" });
  return {
    micEnabled: resp?.micEnabled !== false,
    micDeviceId: typeof resp?.micDeviceId === "string" ? resp.micDeviceId : ""
  };
}
async function setupMicControl() {
  if (!meetingRequiredParam) return;
  const row = $("mic-control-row");
  const toggle = $("mic-toggle");
  const select = $("mic-select");
  if (!row || !toggle || !select) return;
  row.classList.remove("hidden");
  const settings = await getSettings();
  toggle.checked = settings.micEnabled;
  select.disabled = !settings.micEnabled;
  populateDeviceSelect(select, "audioinput", settings.micDeviceId, {
    audio: true
  }).then((result) => {
    if (result === "blocked") select.disabled = true;
  }).catch(() => {
  });
  toggle.addEventListener("change", () => {
    select.disabled = !toggle.checked;
    sendMsg({ type: "SAVE_SETTINGS", settings: { micEnabled: toggle.checked } });
  });
  select.addEventListener("change", () => {
    sendMsg({ type: "SAVE_SETTINGS", settings: { micDeviceId: select.value } });
  });
}
var TAB_AUDIO_UNAVAILABLE_MSG = "Mijoz ovozini ulab bo'lmadi \u2014 Meet tabini yangilab, qaytadan boshlang.";
var SURFACE_NOT_MONITOR_MSG = `To'liq ekranni tanlang \u2014 "Entire Screen". Tab yoki oyna tanlansa, suhbat to'liq yozilmaydi. Qaytadan urinib ko'ring.`;
function failClosedStart(message, streams, startBtn) {
  for (const t of streams.displayStream.getTracks()) t.stop();
  if (streams.micStream) for (const t of streams.micStream.getTracks()) t.stop();
  if (streams.tabAudioStream) {
    for (const t of streams.tabAudioStream.getTracks()) t.stop();
  }
  streams.audioCtx?.close().catch(() => {
  });
  sendMsg({ type: "INSTRUCTION_CANCEL" });
  const el = $("error-msg");
  if (el) el.textContent = message;
  showView("view-error");
  if (startBtn) startBtn.disabled = false;
}
function confirmProceedWithoutClientAudio(displayStream) {
  return new Promise((resolve) => {
    const videoTrack = displayStream.getVideoTracks()[0];
    let settled = false;
    const finish = (proceed) => {
      if (settled) return;
      settled = true;
      if (videoTrack) videoTrack.onended = null;
      resolve(proceed);
    };
    if (videoTrack) {
      videoTrack.onended = () => finish(false);
    }
    showView("view-confirm");
    $("btn-confirm-start")?.addEventListener("click", () => finish(true), {
      once: true
    });
    $("btn-confirm-cancel")?.addEventListener("click", () => finish(false), {
      once: true
    });
  });
}
async function resolveClientAudioGap(streams, startBtn) {
  const proceed = await confirmProceedWithoutClientAudio(streams.displayStream);
  const videoTrack = streams.displayStream.getVideoTracks()[0];
  if (!proceed || !videoTrack || videoTrack.readyState !== "live") {
    failClosedStart(TAB_AUDIO_UNAVAILABLE_MSG, streams, startBtn);
    return false;
  }
  clientAudioWaived = true;
  showView("view-idle");
  setAudioWarn("waived", true);
  return true;
}
async function startRecording() {
  setIdleMsg("", false);
  const startBtn = $("btn-start");
  if (startBtn) startBtn.disabled = true;
  intentionalStop = false;
  clientAudioWaived = false;
  degradedCauses.clear();
  activeAudioWarn.clear();
  renderAudioWarn();
  const settings = await getSettings();
  let displayStream;
  try {
    displayStream = await navigator.mediaDevices.getDisplayMedia({
      video: {
        displaySurface: "monitor",
        width: { max: 1280 },
        height: { max: 720 },
        frameRate: { max: 24 }
      },
      audio: true,
      selfBrowserSurface: "exclude",
      surfaceSwitching: "exclude",
      monitorTypeSurfaces: "include"
    });
  } catch (err) {
    sendMsg({ type: "INSTRUCTION_CANCEL" });
    const name = err instanceof Error ? err.name : "";
    const friendly = name === "NotAllowedError" ? "Screen sharing was cancelled. Click the button to try again." : `Couldn't start screen capture: ${err instanceof Error ? err.message : String(err)}`;
    setIdleMsg(friendly, true);
    if (startBtn) startBtn.disabled = false;
    return;
  }
  if (meetingRequiredParam) {
    const surface = displayStream.getVideoTracks()[0]?.getSettings().displaySurface;
    if (surface === "browser" || surface === "window") {
      for (const t of displayStream.getTracks()) t.stop();
      sendMsg({ type: "INSTRUCTION_CANCEL" });
      setIdleMsg(SURFACE_NOT_MONITOR_MSG, true);
      showView("view-idle");
      if (startBtn) startBtn.disabled = false;
      return;
    }
    if (surface !== "monitor") {
      console.warn(
        `[recorder] meeting surface gate: displaySurface is ${JSON.stringify(surface)}, not "monitor" \u2014 allowing the recording to start (fail-open on unknown).`
      );
    }
  }
  try {
    let micStream = null;
    if (settings.micEnabled && settings.micDeviceId) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: { deviceId: { exact: settings.micDeviceId } }
        });
      } catch {
        try {
          micStream = await navigator.mediaDevices.getUserMedia({
            audio: true
          });
        } catch {
          micStream = null;
        }
      }
    } else if (settings.micEnabled) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch {
        micStream = null;
      }
    }
    let tabAudioStream = null;
    let meetingRequired = false;
    try {
      const resp = await sendMsgAwait({
        type: "REQUEST_TAB_AUDIO",
        sourceTabId,
        meeting: meetingRequiredParam
      });
      meetingRequired = meetingRequiredParam || resp?.required === true;
      const streamId = resp?.streamId;
      if (streamId) {
        try {
          tabAudioStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              mandatory: {
                chromeMediaSource: "tab",
                chromeMediaSourceId: streamId
              }
            },
            video: false
          });
        } catch {
          tabAudioStream = null;
        }
      }
    } catch {
      tabAudioStream = null;
    }
    const haveTabAudio = !!tabAudioStream && tabAudioStream.getAudioTracks().length > 0;
    if (meetingRequired && !haveTabAudio) {
      const ok = await resolveClientAudioGap(
        { displayStream, micStream, tabAudioStream },
        startBtn
      );
      if (!ok) return;
    }
    const audioCtx = new AudioContext({ sampleRate: 48e3 });
    const dest = audioCtx.createMediaStreamDestination();
    if (!haveTabAudio && displayStream.getAudioTracks().length > 0) {
      audioCtx.createMediaStreamSource(displayStream).connect(dest);
    }
    if (micStream && micStream.getAudioTracks().length > 0) {
      audioCtx.createMediaStreamSource(micStream).connect(dest);
    }
    if (haveTabAudio && tabAudioStream) {
      const tabSrc = audioCtx.createMediaStreamSource(tabAudioStream);
      tabSrc.connect(dest);
      tabSrc.connect(audioCtx.destination);
    }
    await audioCtx.resume();
    if (meetingRequired && !clientAudioWaived) {
      const tabTrack = tabAudioStream?.getAudioTracks()[0];
      const destTrack = dest.stream.getAudioTracks()[0];
      const liveOk = audioCtx.state === "running" && isTabAudioLive(tabTrack) && !!destTrack && destTrack.readyState === "live";
      if (!liveOk) {
        const ok = await resolveClientAudioGap(
          { displayStream, micStream, tabAudioStream, audioCtx },
          startBtn
        );
        if (!ok) return;
      }
    }
    const recordStream = new MediaStream([
      ...displayStream.getVideoTracks(),
      ...dest.stream.getAudioTracks()
    ]);
    const mime = pickMimeType();
    const recorder = new MediaRecorder(recordStream, {
      mimeType: mime,
      videoBitsPerSecond: VIDEO_BITS_PER_SECOND,
      audioBitsPerSecond: AUDIO_BITS_PER_SECOND
    });
    let chunkIndex = 0;
    let pendingChunks = 0;
    let stopRequested = false;
    const finishStop = () => {
      if (state) {
        cleanup(state);
        state = null;
      }
      stopTimer();
      sendMsg({ type: "RECORDER_STOPPED" });
    };
    recorder.ondataavailable = async (e) => {
      if (e.data.size <= 0) {
        if (stopRequested && pendingChunks === 0) finishStop();
        return;
      }
      pendingChunks++;
      try {
        const buffer = await e.data.arrayBuffer();
        sendMsg({
          type: "RECORDER_CHUNK",
          chunk: Array.from(new Uint8Array(buffer)),
          index: chunkIndex++,
          mime: recorder.mimeType,
          ts: Date.now()
        });
      } finally {
        pendingChunks--;
        if (stopRequested && pendingChunks === 0) finishStop();
      }
    };
    recorder.onerror = () => {
      sendMsg({ type: "RECORDER_ERROR", error: "MediaRecorder error" });
      if (state) {
        cleanup(state);
        state = null;
      }
    };
    recorder.onstop = () => {
      stopRequested = true;
      if (pendingChunks === 0) finishStop();
    };
    const videoTracks = displayStream.getVideoTracks();
    if (videoTracks.length > 0) {
      videoTracks[0].onended = () => {
        if (state && state.recorder.state !== "inactive") {
          state.recorder.stop();
        }
      };
    }
    state = { recorder, audioCtx, dest, displayStream, micStream, tabAudioStream };
    if (meetingRequired) {
      const tabTrack = tabAudioStream?.getAudioTracks()[0];
      if (tabTrack) {
        tabTrack.onended = () => handleTabAudioDegraded("ended");
        tabTrack.onmute = () => {
          setTimeout(() => {
            if (tabTrack.muted) handleTabAudioDegraded("muted");
          }, 1500);
        };
        tabTrack.onunmute = () => handleTabAudioRecovered("muted");
      }
      audioCtx.onstatechange = () => {
        if (!state) return;
        if (audioCtx.state === "running") {
          handleTabAudioRecovered("suspended");
        } else {
          handleTabAudioDegraded("suspended");
          attemptAudioCtxResume(audioCtx);
        }
      };
    }
    const startResp = await sendMsgAwait({
      type: "RECORDER_STARTED",
      mime,
      hasVideo: displayStream.getVideoTracks().length > 0,
      hasAudio: dest.stream.getAudioTracks().length > 0,
      sourceTabId,
      meeting: meetingRequiredParam,
      meetingId: meetingIdParam
    });
    if (!startResp?.ok) {
      cleanup(state);
      state = null;
      const reason = startResp?.error ?? "Couldn't start the upload session.";
      setIdleMsg(`Couldn't start recording: ${reason}`, true);
      showView("view-idle");
      if (startBtn) startBtn.disabled = false;
      return;
    }
    recorder.start(200);
    showView("view-recording");
    if (!clientAudioWaived) {
      const hasRemoteAudio = displayStream.getAudioTracks().length > 0 || (tabAudioStream?.getAudioTracks().length ?? 0) > 0;
      setAudioWarn("mic-only", !hasRemoteAudio);
    }
    startTimer();
  } catch (err) {
    if (state) {
      cleanup(state);
      state = null;
    }
    sendMsg({
      type: "RECORDER_ERROR",
      error: err instanceof Error ? err.message : String(err)
    });
    setIdleMsg(
      `Couldn't start recording: ${err instanceof Error ? err.message : String(err)}`,
      true
    );
    showView("view-idle");
    if (startBtn) startBtn.disabled = false;
  }
}
function stopRecording() {
  intentionalStop = true;
  if (state && state.recorder.state !== "inactive") {
    state.recorder.stop();
  } else {
    stopTimer();
    sendMsg({ type: "RECORDER_STOPPED" });
  }
}
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function handleStateChange(s) {
  switch (s.kind) {
    case "recording": {
      if (!state) {
        stopTimer();
        showView("view-idle");
        const startBtn = $("btn-start");
        if (startBtn) startBtn.disabled = true;
        setIdleMsg(
          "A recording is already in progress. Stop it before starting a new one.",
          false
        );
      }
      break;
    }
    case "uploading": {
      stopTimer();
      const pct = s.totalBytes && s.totalBytes > 0 ? Math.round((s.uploadedBytes ?? 0) / s.totalBytes * 100) : 0;
      const el = $("upload-progress");
      if (el) {
        el.textContent = `${formatBytes(s.uploadedBytes ?? 0)} uploaded (${pct}%)`;
      }
      showView("view-uploading");
      break;
    }
    case "finishing": {
      stopTimer();
      const el = $("upload-progress");
      if (el) el.textContent = "Finishing up\u2026";
      showView("view-uploading");
      break;
    }
    case "complete": {
      stopTimer();
      lastShareUrl = s.shareUrl ?? "";
      const el = $("complete-url");
      if (el) el.textContent = lastShareUrl;
      showView("view-complete");
      break;
    }
    case "error": {
      stopTimer();
      if (state) {
        if (state.recorder.state !== "inactive") {
          try {
            state.recorder.stop();
          } catch (_) {
          }
        }
        cleanup(state);
        state = null;
      }
      const el = $("error-msg");
      if (el) el.textContent = s.reason ?? "Unknown error";
      showView("view-error");
      break;
    }
    case "idle": {
      if (!state) {
        stopTimer();
        showView("view-idle");
        const startBtn = $("btn-start");
        if (startBtn) startBtn.disabled = false;
        setIdleMsg("", false);
      }
      break;
    }
  }
}
function wire() {
  $("btn-start")?.addEventListener("click", () => {
    startRecording().catch((err) => {
      setIdleMsg(
        `Couldn't start: ${err instanceof Error ? err.message : String(err)}`,
        true
      );
    });
  });
  $("btn-cancel")?.addEventListener("click", () => {
    window.close();
  });
  $("btn-meet-tab-only")?.addEventListener("click", () => {
    sendMsg({ type: "INSTRUCTION_CANCEL" });
    const msg = { type: "START_MEET" };
    if (sourceTabId !== void 0) msg.tabId = sourceTabId;
    if (meetingIdParam) msg.meetingId = meetingIdParam;
    sendMsg(msg);
    window.close();
  });
  $("btn-pause")?.addEventListener("click", () => {
    void (async () => {
      if (!state || state.recorder.state === "inactive") return;
      const command = state.recorder.state === "paused" ? "RESUME" : "PAUSE";
      const btn = $("btn-pause");
      if (btn) {
        btn.disabled = true;
        btn.textContent = command === "PAUSE" ? "Pausing\u2026" : "Resuming\u2026";
      }
      setCtlMsg("");
      controlInFlight = true;
      const result = await sendCaptureCommand(sendMsgAwait, command);
      controlInFlight = false;
      setCtlMsg(result.ok ? "" : result.error);
      syncPauseLabel();
    })();
  });
  $("btn-stop")?.addEventListener("click", () => {
    const btn = $("btn-stop");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Finishing\u2026";
    }
    stopRecording();
  });
  $("btn-copy")?.addEventListener("click", () => {
    if (!lastShareUrl) return;
    navigator.clipboard.writeText(lastShareUrl).then(() => {
      const btn = $("btn-copy");
      if (btn) {
        btn.textContent = "Copied!";
        setTimeout(() => {
          btn.textContent = "Copy link";
        }, 2e3);
      }
    });
  });
  $("btn-open")?.addEventListener("click", () => {
    if (lastShareUrl) chrome.tabs.create({ url: lastShareUrl });
  });
  $("btn-close")?.addEventListener("click", () => {
    sendMsg({ type: "CANCEL" });
    window.close();
  });
  $("btn-retry")?.addEventListener("click", () => {
    sendMsg({ type: "RETRY" });
    showView("view-idle");
    const startBtn = $("btn-start");
    if (startBtn) startBtn.disabled = false;
    setIdleMsg("", false);
  });
  $("btn-close-err")?.addEventListener("click", () => {
    sendMsg({ type: "CANCEL" });
    window.close();
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (typeof message !== "object" || message === null) return;
    const msg = message;
    if (msg.type === "STATE_CHANGED") {
      const s = msg.state;
      if (s) handleStateChange(s);
    } else if (msg.type === "STOP_CAPTURE") {
      if (state) {
        stopRecording();
        sendResponse({ ok: true });
      }
    } else if (msg.type === "PAUSE_CAPTURE") {
      if (state && state.recorder.state === "recording") {
        state.recorder.pause();
        pauseTimer();
        syncPauseLabel();
        sendResponse({ ok: true });
      }
    } else if (msg.type === "RESUME_CAPTURE") {
      if (state && state.recorder.state === "paused") {
        state.recorder.resume();
        resumeTimer();
        syncPauseLabel();
        sendResponse({ ok: true });
      }
    } else if (msg.type === "TAB_AUDIO_LOST_REMOTE") {
      handleTabAudioDegraded("ended");
      sendResponse({ ok: true });
    }
  });
  window.addEventListener("beforeunload", () => {
    intentionalStop = true;
    if (state && state.recorder.state !== "inactive") {
      state.recorder.stop();
    } else if (!state) {
      sendMsg({ type: "INSTRUCTION_CANCEL" });
    }
  });
}
function applyMeetingCopy() {
  if (!meetingRequiredParam) return;
  document.title = "data365 \u2014 Record full-screen meeting";
  const title = $("idle-title");
  if (title) title.textContent = "Record full-screen meeting";
  const sub = $("idle-sub");
  if (sub) {
    sub.textContent = `Click below, then choose "Entire Screen" so everything you show is recorded. The other participants' voices are captured from your Meet tab automatically \u2014 leave that tab open, and keep this one open too.`;
  }
  const start = $("btn-start");
  if (start) start.textContent = "Boshlash";
  const meetTabOnlyBtn = $("btn-meet-tab-only");
  if (meetTabOnlyBtn) meetTabOnlyBtn.classList.remove("hidden");
}
showView("view-idle");
applyMeetingCopy();
wire();
void setupMicControl();
//# sourceMappingURL=recorder-page.js.map
