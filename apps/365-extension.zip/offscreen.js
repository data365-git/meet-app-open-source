// src/shared/client-audio.ts
var TAB_AUDIO_PROBLEM = {
  missing: "the tab isn't exposing any audio",
  ended: "the tab's audio stopped",
  muted: "the tab is muted in Chrome (right-click the tab \u2192 Unmute site)"
};
function tabAudioStatus(track) {
  if (!track) return "missing";
  if (track.readyState !== "live") return "ended";
  if (track.muted) return "muted";
  return "live";
}
function isTabAudioLive(track) {
  return tabAudioStatus(track) === "live";
}

// src/shared/recording-quality.ts
var VIDEO_BITS_PER_SECOND = 3e6;
var AUDIO_BITS_PER_SECOND = 128e3;
var TAB_AUDIO_GAIN = 1.8;

// src/offscreen/recorder.ts
var state = null;
function noClientAudioError(problem) {
  return new Error(
    `Can't record this meeting: ${problem}, so the other participants wouldn't be recorded. Unmute the tab and try again, or use "Record full-screen meeting".`
  );
}
function pickMimeType() {
  const candidates = [
    "video/mp4;codecs=h264",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return "video/webm";
}
function sendMsg(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
  });
}
function sendMsgAwait(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}
function cleanup(s) {
  for (const t of s.displayStream.getTracks()) t.stop();
  if (s.micStream) for (const t of s.micStream.getTracks()) t.stop();
  s.audioCtx.close().catch(() => {
  });
}
async function startCapture(msg) {
  if (state) {
    cleanup(state);
    state = null;
  }
  try {
    if (!msg.streamId) throw new Error("streamId required for tab capture");
    let displayStream;
    try {
      displayStream = await navigator.mediaDevices.getUserMedia({
        video: {
          mandatory: {
            chromeMediaSource: "tab",
            chromeMediaSourceId: msg.streamId
          }
        },
        audio: {
          mandatory: {
            chromeMediaSource: "tab",
            chromeMediaSourceId: msg.streamId
          }
        }
      });
    } catch (err) {
      throw noClientAudioError(
        `${TAB_AUDIO_PROBLEM.missing} (${err instanceof Error ? err.message : String(err)})`
      );
    }
    const startStatus = tabAudioStatus(displayStream.getAudioTracks()[0]);
    if (startStatus !== "live") {
      for (const t of displayStream.getTracks()) t.stop();
      throw noClientAudioError(TAB_AUDIO_PROBLEM[startStatus]);
    }
    let micStream = null;
    if (msg.micEnabled !== false) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({
          audio: msg.micDeviceId ? { deviceId: { exact: msg.micDeviceId } } : true
        });
      } catch {
        try {
          micStream = await navigator.mediaDevices.getUserMedia({
            audio: true
          });
        } catch {
          micStream = null;
        }
      }
    }
    const audioCtx = new AudioContext({ sampleRate: 48e3 });
    const dest = audioCtx.createMediaStreamDestination();
    if (displayStream.getAudioTracks().length > 0) {
      const displaySrc = audioCtx.createMediaStreamSource(displayStream);
      const tabGain = audioCtx.createGain();
      tabGain.gain.value = TAB_AUDIO_GAIN;
      displaySrc.connect(tabGain).connect(dest);
      displaySrc.connect(audioCtx.destination);
    }
    if (micStream && micStream.getAudioTracks().length > 0) {
      audioCtx.createMediaStreamSource(micStream).connect(dest);
    }
    const recordStream = new MediaStream([
      ...displayStream.getVideoTracks(),
      ...dest.stream.getAudioTracks()
    ]);
    const mime = pickMimeType();
    const recorder = new MediaRecorder(recordStream, {
      mimeType: mime,
      videoBitsPerSecond: VIDEO_BITS_PER_SECOND,
      audioBitsPerSecond: AUDIO_BITS_PER_SECOND
    });
    let chunkIndex = 0;
    let pendingChunks = 0;
    let stopRequested = false;
    const finishStop = () => {
      if (state) {
        cleanup(state);
        state = null;
      }
      sendMsg({ type: "RECORDER_STOPPED" });
    };
    recorder.ondataavailable = async (e) => {
      if (e.data.size <= 0) {
        if (stopRequested && pendingChunks === 0) finishStop();
        return;
      }
      pendingChunks++;
      try {
        const buffer = await e.data.arrayBuffer();
        sendMsg({
          type: "RECORDER_CHUNK",
          chunk: Array.from(new Uint8Array(buffer)),
          index: chunkIndex++,
          mime: recorder.mimeType,
          ts: Date.now()
        });
      } finally {
        pendingChunks--;
        if (stopRequested && pendingChunks === 0) finishStop();
      }
    };
    recorder.onerror = () => {
      sendMsg({ type: "RECORDER_ERROR", error: "MediaRecorder error" });
      if (state) {
        cleanup(state);
        state = null;
      }
    };
    recorder.onstop = () => {
      stopRequested = true;
      if (pendingChunks === 0) finishStop();
    };
    const videoTracks = displayStream.getVideoTracks();
    if (videoTracks.length > 0) {
      videoTracks[0].onended = () => {
        if (state && state.recorder.state !== "inactive") {
          state.recorder.stop();
        }
      };
    }
    state = { recorder, audioCtx, displayStream, micStream, chunkIndex };
    const tabAudioTrack = displayStream.getAudioTracks()[0];
    if (tabAudioTrack) {
      const isThisRecording = () => state?.displayStream === displayStream;
      tabAudioTrack.onmute = () => {
        setTimeout(() => {
          if (isThisRecording() && state?.recorder.state !== void 0 && state.recorder.state !== "inactive" && !isTabAudioLive(tabAudioTrack)) {
            sendMsg({ type: "TAB_AUDIO_DEGRADED", cause: "muted" });
          }
        }, 1500);
      };
      tabAudioTrack.onunmute = () => {
        if (isThisRecording() && state?.recorder.state !== "inactive" && isTabAudioLive(tabAudioTrack)) {
          sendMsg({ type: "TAB_AUDIO_RECOVERED" });
        }
      };
    }
    const startResp = await sendMsgAwait({
      type: "RECORDER_STARTED",
      mime,
      hasVideo: displayStream.getVideoTracks().length > 0,
      hasAudio: dest.stream.getAudioTracks().length > 0
    });
    if (!startResp?.ok) {
      if (state) {
        cleanup(state);
        state = null;
      }
      sendMsg({
        type: "RECORDER_ERROR",
        error: startResp?.error ?? "Couldn't start the upload session."
      });
      return;
    }
    recorder.start(200);
  } catch (err) {
    sendMsg({
      type: "RECORDER_ERROR",
      error: err instanceof Error ? err.message : String(err)
    });
    if (state) {
      cleanup(state);
      state = null;
    }
  }
}
chrome.runtime.onMessage.addListener((raw, _sender, sendResponse) => {
  const msg = raw;
  if (msg.type === "START_CAPTURE") {
    startCapture(msg).catch((err) => {
      sendMsg({
        type: "RECORDER_ERROR",
        error: err instanceof Error ? err.message : String(err)
      });
    });
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "STOP_CAPTURE") {
    if (!state) {
      sendResponse({ ok: true });
      return;
    }
    if (state.recorder.state !== "inactive") {
      state.recorder.stop();
    } else {
      cleanup(state);
      state = null;
      sendMsg({ type: "RECORDER_STOPPED" });
    }
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "PAUSE_CAPTURE") {
    if (state && state.recorder.state === "recording") {
      state.recorder.pause();
      sendResponse({ ok: true });
    }
    return;
  }
  if (msg.type === "RESUME_CAPTURE") {
    if (state && state.recorder.state === "paused") {
      state.recorder.resume();
      sendResponse({ ok: true });
    }
    return;
  }
});
//# sourceMappingURL=offscreen.js.map
