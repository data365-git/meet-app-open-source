globalThis.process = Object.assign({}, globalThis.process); globalThis.process.env = Object.assign({}, globalThis.process.env, {});

// src/shared/client-audio.ts
var TAB_AUDIO_PROBLEM = {
  missing: "the tab isn't exposing any audio",
  ended: "the tab's audio stopped",
  muted: "the tab is muted in Chrome (right-click the tab \u2192 Unmute site)"
};
function tabAudioStatus(track) {
  if (!track) return "missing";
  if (track.readyState !== "live") return "ended";
  if (track.muted) return "muted";
  return "live";
}
function isTabAudioLive(track) {
  return tabAudioStatus(track) === "live";
}

// src/shared/recording-quality.ts
var CAPTURE_MAX_WIDTH = 1920;
var CAPTURE_MAX_HEIGHT = 1080;
var CAPTURE_MAX_FRAME_RATE = 24;
var extensionEnv = globalThis.process?.env;
function envBitsPerSecond(key, fallback) {
  const raw = extensionEnv?.[key]?.trim();
  if (!raw) return fallback;
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || !Number.isInteger(parsed) || parsed <= 0) {
    return fallback;
  }
  return parsed;
}
var VIDEO_BITRATE_ENV_KEY = "EXTENSION_VIDEO_BITS_PER_SECOND";
var DEFAULT_VIDEO_BITS_PER_SECOND = 8e6;
var VIDEO_BITS_PER_SECOND = envBitsPerSecond(
  VIDEO_BITRATE_ENV_KEY,
  DEFAULT_VIDEO_BITS_PER_SECOND
);
var AUDIO_BITS_PER_SECOND = 128e3;
var MIC_AUDIO_CONSTRAINTS = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
  sampleRate: 48e3,
  channelCount: 1
};
function micAudioConstraints(deviceId) {
  return deviceId ? { ...MIC_AUDIO_CONSTRAINTS, deviceId: { exact: deviceId } } : { ...MIC_AUDIO_CONSTRAINTS };
}
var TAB_AUDIO_CONSTRAINTS = {
  echoCancellation: false,
  noiseSuppression: false,
  autoGainControl: false
};
function tabAudioConstraints(streamId) {
  return {
    mandatory: {
      chromeMediaSource: "tab",
      chromeMediaSourceId: streamId,
      echoCancellation: TAB_AUDIO_CONSTRAINTS.echoCancellation,
      noiseSuppression: TAB_AUDIO_CONSTRAINTS.noiseSuppression,
      autoGainControl: TAB_AUDIO_CONSTRAINTS.autoGainControl,
      googEchoCancellation: TAB_AUDIO_CONSTRAINTS.echoCancellation,
      googNoiseSuppression: TAB_AUDIO_CONSTRAINTS.noiseSuppression,
      googAutoGainControl: TAB_AUDIO_CONSTRAINTS.autoGainControl
    }
  };
}
var TAB_AUDIO_GAIN = 1.8;
function createMixLimiter(audioCtx) {
  const limiter = audioCtx.createDynamicsCompressor();
  limiter.threshold.value = -3;
  limiter.knee.value = 0;
  limiter.ratio.value = 20;
  limiter.attack.value = 3e-3;
  limiter.release.value = 0.25;
  return limiter;
}
var CAPTURE_TIERS = [
  {
    name: "full",
    maxWidth: CAPTURE_MAX_WIDTH,
    maxHeight: CAPTURE_MAX_HEIGHT,
    frameRate: CAPTURE_MAX_FRAME_RATE,
    videoBitsPerSecond: VIDEO_BITS_PER_SECOND,
    audioBitsPerSecond: AUDIO_BITS_PER_SECOND
  },
  {
    name: "reduced",
    maxWidth: 1280,
    maxHeight: 720,
    frameRate: 15,
    videoBitsPerSecond: Math.min(VIDEO_BITS_PER_SECOND, 25e5),
    audioBitsPerSecond: AUDIO_BITS_PER_SECOND
  },
  {
    name: "minimal",
    maxWidth: 854,
    maxHeight: 480,
    frameRate: 10,
    videoBitsPerSecond: Math.min(VIDEO_BITS_PER_SECOND, 8e5),
    audioBitsPerSecond: AUDIO_BITS_PER_SECOND
  }
];
var PART_BYTES = 5 * 1024 * 1024;
var BACKLOG_DEGRADE_ABOVE_BYTES = 3 * PART_BYTES;
var BACKLOG_RESTORE_BELOW_BYTES = 1 * PART_BYTES;
function pickMimeType() {
  const candidates = [
    "video/mp4;codecs=h264",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return "video/webm";
}

// src/shared/recorder-session.ts
function newSessionId() {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  return `rs-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

// src/offscreen/recorder.ts
var state = null;
var startInFlight = false;
var MIC_ACQUIRE_TIMEOUT_MS = 8e3;
function withTimeout(p, ms) {
  let settled = false;
  const guarded = p.then((stream) => {
    if (settled) {
      for (const t of stream.getTracks()) t.stop();
      return null;
    }
    return stream;
  }).catch(() => null);
  return Promise.race([
    guarded,
    new Promise(
      (resolve) => setTimeout(() => {
        settled = true;
        resolve(null);
      }, ms)
    )
  ]);
}
function noClientAudioError(problem) {
  return new Error(
    `Can't record this meeting: ${problem}, so the other participants wouldn't be recorded. Unmute the tab and try again, or use "Record full-screen meeting".`
  );
}
function sendMsg(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
  });
}
function sendMsgAwait(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}
function cleanup(s) {
  for (const t of s.displayStream.getTracks()) t.stop();
  if (s.micStream) for (const t of s.micStream.getTracks()) t.stop();
  s.audioCtx.close().catch(() => {
  });
}
async function startCapture(msg) {
  if (startInFlight) {
    console.warn("[offscreen] START_CAPTURE ignored: a start is already running");
    return;
  }
  startInFlight = true;
  try {
    if (state) {
      cleanup(state);
      state = null;
    }
    const mySessionId = newSessionId();
    let ownDisplayStream = null;
    let ownMicStream = null;
    let ownAudioCtx = null;
    const releaseOwnMedia = () => {
      if (ownDisplayStream) for (const t of ownDisplayStream.getTracks()) t.stop();
      if (ownMicStream) for (const t of ownMicStream.getTracks()) t.stop();
      ownAudioCtx?.close().catch(() => {
      });
      ownDisplayStream = null;
      ownMicStream = null;
      ownAudioCtx = null;
    };
    try {
      if (!msg.streamId) throw new Error("streamId required for tab capture");
      let displayStream;
      try {
        displayStream = await navigator.mediaDevices.getUserMedia({
          video: {
            mandatory: {
              chromeMediaSource: "tab",
              chromeMediaSourceId: msg.streamId
            }
          },
          // Unprocessed on purpose — see TAB_AUDIO_CONSTRAINTS: AEC/NS/AGC on
          // a tab stream would gate the remote participant's voice.
          audio: tabAudioConstraints(msg.streamId)
        });
      } catch (err) {
        throw noClientAudioError(
          `${TAB_AUDIO_PROBLEM.missing} (${err instanceof Error ? err.message : String(err)})`
        );
      }
      ownDisplayStream = displayStream;
      const startStatus = tabAudioStatus(displayStream.getAudioTracks()[0]);
      if (startStatus !== "live") {
        for (const t of displayStream.getTracks()) t.stop();
        throw noClientAudioError(TAB_AUDIO_PROBLEM[startStatus]);
      }
      let micStream = null;
      if (msg.micEnabled !== false) {
        micStream = await withTimeout(
          navigator.mediaDevices.getUserMedia({
            audio: micAudioConstraints(msg.micDeviceId)
          }),
          MIC_ACQUIRE_TIMEOUT_MS
        );
        if (!micStream) {
          micStream = await withTimeout(
            navigator.mediaDevices.getUserMedia({
              audio: micAudioConstraints()
            }),
            MIC_ACQUIRE_TIMEOUT_MS
          );
        }
      }
      ownMicStream = micStream;
      const audioCtx = new AudioContext({ sampleRate: 48e3 });
      ownAudioCtx = audioCtx;
      const dest = audioCtx.createMediaStreamDestination();
      const limiter = createMixLimiter(audioCtx);
      limiter.connect(dest);
      if (displayStream.getAudioTracks().length > 0) {
        const displaySrc = audioCtx.createMediaStreamSource(displayStream);
        const tabGain = audioCtx.createGain();
        tabGain.gain.value = TAB_AUDIO_GAIN;
        displaySrc.connect(tabGain).connect(limiter);
        displaySrc.connect(audioCtx.destination);
      }
      if (micStream && micStream.getAudioTracks().length > 0) {
        audioCtx.createMediaStreamSource(micStream).connect(limiter);
      }
      const recordStream = new MediaStream([
        ...displayStream.getVideoTracks(),
        ...dest.stream.getAudioTracks()
      ]);
      const mime = pickMimeType();
      const recorder = new MediaRecorder(recordStream, {
        mimeType: mime,
        videoBitsPerSecond: VIDEO_BITS_PER_SECOND,
        audioBitsPerSecond: AUDIO_BITS_PER_SECOND
      });
      let chunkIndex = 0;
      let pendingChunks = 0;
      let stopRequested = false;
      const isMine = () => state !== null && state.sessionId === mySessionId;
      const retireOrphan = () => {
        try {
          if (recorder.state !== "inactive") recorder.stop();
        } catch {
        }
        for (const t of displayStream.getTracks()) t.stop();
        if (micStream) for (const t of micStream.getTracks()) t.stop();
        audioCtx.close().catch(() => {
        });
      };
      const finishStop = () => {
        if (!isMine()) {
          retireOrphan();
          return;
        }
        if (state) {
          cleanup(state);
          state = null;
        }
        sendMsg({ type: "RECORDER_STOPPED", sessionId: mySessionId });
      };
      recorder.ondataavailable = async (e) => {
        if (e.data.size <= 0) {
          if (stopRequested && pendingChunks === 0) finishStop();
          return;
        }
        pendingChunks++;
        try {
          const buffer = await e.data.arrayBuffer();
          if (!isMine()) {
            retireOrphan();
            return;
          }
          const reply = await sendMsgAwait({
            type: "RECORDER_CHUNK",
            chunk: Array.from(new Uint8Array(buffer)),
            index: chunkIndex++,
            mime: recorder.mimeType,
            ts: Date.now(),
            sessionId: mySessionId
          });
          if (reply?.reason === "stale-session") retireOrphan();
        } finally {
          pendingChunks--;
          if (stopRequested && pendingChunks === 0) finishStop();
        }
      };
      recorder.onerror = () => {
        if (!isMine()) {
          retireOrphan();
          return;
        }
        sendMsg({
          type: "RECORDER_ERROR",
          error: "MediaRecorder error",
          sessionId: mySessionId
        });
        if (state) {
          cleanup(state);
          state = null;
        }
      };
      recorder.onstop = () => {
        stopRequested = true;
        if (pendingChunks === 0) finishStop();
      };
      const videoTracks = displayStream.getVideoTracks();
      if (videoTracks.length > 0) {
        videoTracks[0].onended = () => {
          if (state && state.sessionId === mySessionId) {
            if (state.recorder.state !== "inactive") state.recorder.stop();
            return;
          }
          if (recorder.state !== "inactive") {
            try {
              recorder.stop();
            } catch {
            }
          }
          for (const t of displayStream.getTracks()) t.stop();
        };
      }
      state = {
        sessionId: mySessionId,
        recorder,
        audioCtx,
        displayStream,
        micStream,
        chunkIndex
      };
      const tabAudioTrack = displayStream.getAudioTracks()[0];
      if (tabAudioTrack) {
        const isThisRecording = () => state?.displayStream === displayStream;
        tabAudioTrack.onmute = () => {
          setTimeout(() => {
            if (isThisRecording() && state?.recorder.state !== void 0 && state.recorder.state !== "inactive" && !isTabAudioLive(tabAudioTrack)) {
              sendMsg({ type: "TAB_AUDIO_DEGRADED", cause: "muted" });
            }
          }, 1500);
        };
        tabAudioTrack.onunmute = () => {
          if (isThisRecording() && state?.recorder.state !== "inactive" && isTabAudioLive(tabAudioTrack)) {
            sendMsg({ type: "TAB_AUDIO_RECOVERED" });
          }
        };
      }
      const startResp = await sendMsgAwait({
        type: "RECORDER_STARTED",
        mime,
        hasVideo: displayStream.getVideoTracks().length > 0,
        hasAudio: dest.stream.getAudioTracks().length > 0,
        // (F2) Registers THIS session as the owner of the upload.
        sessionId: mySessionId
      });
      if (!startResp?.ok) {
        const quiet = startResp?.reason === "start-in-flight" || startResp?.reason === "stale-session";
        if (state && state.sessionId === mySessionId) {
          cleanup(state);
          state = null;
        } else {
          releaseOwnMedia();
        }
        if (!quiet) {
          sendMsg({
            type: "RECORDER_ERROR",
            error: startResp?.error ?? "Couldn't start the upload session.",
            sessionId: mySessionId
          });
        } else {
          console.warn("[offscreen] start refused:", startResp?.error);
        }
        return;
      }
      recorder.start(200);
    } catch (err) {
      sendMsg({
        type: "RECORDER_ERROR",
        error: err instanceof Error ? err.message : String(err),
        sessionId: mySessionId
      });
      if (state && state.sessionId === mySessionId) {
        cleanup(state);
        state = null;
      } else {
        releaseOwnMedia();
      }
    }
  } finally {
    startInFlight = false;
  }
}
chrome.runtime.onMessage.addListener((raw, _sender, sendResponse) => {
  const msg = raw;
  if (msg.type === "START_CAPTURE") {
    startCapture(msg).catch((err) => {
      console.error("[offscreen] startCapture failed:", err);
    });
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "STOP_CAPTURE") {
    if (!state) {
      sendResponse({ ok: true });
      return;
    }
    if (state.recorder.state !== "inactive") {
      state.recorder.stop();
    } else {
      const sessionId = state.sessionId;
      cleanup(state);
      state = null;
      sendMsg({ type: "RECORDER_STOPPED", sessionId });
    }
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "PAUSE_CAPTURE") {
    if (state && state.recorder.state === "recording") {
      state.recorder.pause();
      sendResponse({ ok: true });
    }
    return;
  }
  if (msg.type === "RESUME_CAPTURE") {
    if (state && state.recorder.state === "paused") {
      state.recorder.resume();
      sendResponse({ ok: true });
    }
    return;
  }
});
//# sourceMappingURL=offscreen.js.map
