globalThis.process = Object.assign({}, globalThis.process); globalThis.process.env = Object.assign({}, globalThis.process.env, {});
"use strict";
(() => {
  // src/shared/meeting-url.ts
  function getMeetingId(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      if (!parsed.hostname.endsWith("meet.google.com")) return null;
      const match = /^\/([a-z]+-[a-z]+-[a-z]+)$/i.exec(parsed.pathname);
      return match?.[1] ?? null;
    } catch {
      return null;
    }
  }

  // src/shared/recording-quality.ts
  var CAPTURE_MAX_WIDTH = 1920;
  var CAPTURE_MAX_HEIGHT = 1080;
  var CAPTURE_MAX_FRAME_RATE = 24;
  var extensionEnv = globalThis.process?.env;
  function envBitsPerSecond(key, fallback) {
    const raw = extensionEnv?.[key]?.trim();
    if (!raw) return fallback;
    const parsed = Number(raw);
    if (!Number.isFinite(parsed) || !Number.isInteger(parsed) || parsed <= 0) {
      return fallback;
    }
    return parsed;
  }
  var VIDEO_BITRATE_ENV_KEY = "EXTENSION_VIDEO_BITS_PER_SECOND";
  var DEFAULT_VIDEO_BITS_PER_SECOND = 8e6;
  var VIDEO_BITS_PER_SECOND = envBitsPerSecond(
    VIDEO_BITRATE_ENV_KEY,
    DEFAULT_VIDEO_BITS_PER_SECOND
  );
  var AUDIO_BITS_PER_SECOND = 128e3;
  var MIC_AUDIO_CONSTRAINTS = {
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true,
    sampleRate: 48e3,
    channelCount: 1
  };
  function micAudioConstraints(deviceId) {
    return deviceId ? { ...MIC_AUDIO_CONSTRAINTS, deviceId: { exact: deviceId } } : { ...MIC_AUDIO_CONSTRAINTS };
  }
  var TAB_AUDIO_GAIN = 1.8;
  function pickMimeType() {
    const candidates = [
      "video/mp4;codecs=h264",
      "video/mp4",
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm"
    ];
    for (const mime of candidates) {
      if (MediaRecorder.isTypeSupported(mime)) return mime;
    }
    return "video/webm";
  }

  // src/shared/recorder-session.ts
  function newSessionId() {
    const c = globalThis.crypto;
    if (c && typeof c.randomUUID === "function") return c.randomUUID();
    return `rs-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }

  // src/content/inpage-recorder.ts
  var state = null;
  var startInFlight = false;
  var intentionalStop = false;
  var clientAudioWaived = false;
  var SURFACE_NOT_MONITOR_MSG = `Choose "Entire Screen" \u2014 picking a tab or window won't record the full call. Please try again.`;
  var NO_CLIENT_AUDIO_MSG = "The other person's audio wasn't captured \u2014 recording cancelled. Try again with Ctrl+Shift+9.";
  var SILENCE_WARN_MSG = "\u26A0\uFE0F No sound has come through the call for 2 minutes. If someone is speaking, open the Meet tab and check it isn't muted \u2014 if you are alone or nobody is talking, ignore this.";
  var SILENCE_WARN_MS = 12e4;
  var WATCHDOG_TICK_MS = 1e3;
  var ENERGY_FLOOR = 0.01;
  function isInPageRecording() {
    return state !== null && state.recorder.state !== "inactive";
  }
  function sendMsg(msg) {
    chrome.runtime.sendMessage(msg).catch(() => {
    });
  }
  function sendMsgAwait(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(response);
        }
      });
    });
  }
  function friendlyStartError(error) {
    const raw = typeof error === "string" ? error.toLowerCase() : "";
    if (raw.includes("already")) return "A recording is already in progress.";
    if (raw.includes("not signed")) {
      return "Sign in with data365 first by clicking the icon.";
    }
    if (raw.includes("meet tab") || raw.includes("tab")) {
      return 'Open this Meet tab and press "Record now" again.';
    }
    return "Couldn't start recording. Try again with Ctrl+Shift+9.";
  }
  function captureFrom(el) {
    const capturable = el;
    const grab = capturable.captureStream ?? capturable.mozCaptureStream;
    if (typeof grab !== "function") return null;
    try {
      const stream = grab.call(capturable);
      return stream.getAudioTracks().length > 0 ? stream : null;
    } catch {
      return null;
    }
  }
  function attachPageAudio(s) {
    let added = 0;
    const media = document.querySelectorAll("audio, video");
    for (const el of media) {
      if (!el.isConnected) continue;
      const stream = captureFrom(el);
      if (!stream) continue;
      const track = stream.getAudioTracks().find((t) => t.readyState === "live");
      if (!track) continue;
      const existing = s.taps.get(el);
      if (existing && existing.trackId === track.id) continue;
      if (existing) {
        try {
          existing.source.disconnect();
        } catch {
        }
      }
      let source;
      try {
        source = s.audioCtx.createMediaStreamSource(new MediaStream([track]));
      } catch {
        continue;
      }
      source.connect(s.pageGain);
      if (s.analyser) source.connect(s.analyser);
      s.taps.set(el, { stream, source, trackId: track.id });
      added++;
    }
    if (added > 0 && s.systemGain) {
      s.systemGain.gain.value = 0;
      s.systemGain = null;
    }
    return added;
  }
  function pruneDeadTaps(s) {
    let pruned = 0;
    for (const [el, tap] of s.taps) {
      if (el.isConnected) continue;
      try {
        tap.source.disconnect();
      } catch {
      }
      s.taps.delete(el);
      pruned++;
    }
    return pruned;
  }
  function detachAllPageAudio(s) {
    for (const tap of s.taps.values()) {
      try {
        tap.source.disconnect();
      } catch {
      }
    }
    s.taps.clear();
  }
  function pageAudioPeak(s, buf) {
    if (!s.analyser) return 0;
    s.analyser.getFloatTimeDomainData(buf);
    let peak = 0;
    for (const v of buf) {
      const a = Math.abs(v);
      if (a > peak) peak = a;
    }
    return peak;
  }
  function cleanup(s) {
    if (!s) return;
    if (s.watchdog !== null) clearInterval(s.watchdog);
    s.rescan?.disconnect();
    detachAllPageAudio(s);
    for (const t of s.displayStream.getTracks()) t.stop();
    if (s.micStream) for (const t of s.micStream.getTracks()) t.stop();
    s.audioCtx.close().catch(() => {
    });
  }
  function stopInPageRecording() {
    intentionalStop = true;
    if (state && state.recorder.state !== "inactive") {
      state.recorder.stop();
    } else if (state) {
      const sessionId = state.sessionId;
      cleanup(state);
      state = null;
      sendMsg({ type: "RECORDER_STOPPED", sessionId });
    }
  }
  function pauseInPageRecording() {
    if (state && state.recorder.state === "recording") {
      state.recorder.pause();
      return true;
    }
    return false;
  }
  function resumeInPageRecording() {
    if (state && state.recorder.state === "paused") {
      state.recorder.resume();
      return true;
    }
    return false;
  }
  var MIC_ACQUIRE_TIMEOUT_MS = 8e3;
  function withTimeout(p, ms) {
    let settled = false;
    const guarded = p.then((stream) => {
      if (settled) {
        for (const t of stream.getTracks()) t.stop();
        return null;
      }
      return stream;
    }).catch(() => null);
    return Promise.race([
      guarded,
      new Promise(
        (resolve) => setTimeout(() => {
          settled = true;
          resolve(null);
        }, ms)
      )
    ]);
  }
  async function getOptionalMicStream(micEnabled, micDeviceId) {
    if (!micEnabled) return null;
    if (micDeviceId) {
      const exact = await withTimeout(
        navigator.mediaDevices.getUserMedia({
          audio: micAudioConstraints(micDeviceId)
        }),
        MIC_ACQUIRE_TIMEOUT_MS
      );
      if (exact) return exact;
    }
    return withTimeout(
      navigator.mediaDevices.getUserMedia({ audio: micAudioConstraints() }),
      MIC_ACQUIRE_TIMEOUT_MS
    );
  }
  async function startInPageRecording(meetingId2, host) {
    if (state || startInFlight) {
      host.note("A recording is already in progress.", true);
      host.onFailed();
      return;
    }
    startInFlight = true;
    try {
      const mySessionId = newSessionId();
      let openedAudioCtx = null;
      let openedMicStream = null;
      intentionalStop = false;
      clientAudioWaived = false;
      let displayStream;
      try {
        displayStream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            displaySurface: "monitor",
            width: { max: CAPTURE_MAX_WIDTH },
            height: { max: CAPTURE_MAX_HEIGHT },
            frameRate: { max: CAPTURE_MAX_FRAME_RATE }
          },
          audio: true,
          surfaceSwitching: "exclude",
          monitorTypeSurfaces: "include"
        });
      } catch (err) {
        const name = err instanceof Error ? err.name : "";
        host.note(
          name === "NotAllowedError" || name === "AbortError" ? "Screen sharing was cancelled. Click again to retry." : `Couldn't share the screen: ${err instanceof Error ? err.message : String(err)}`,
          true
        );
        host.onFailed();
        return;
      }
      if (displayStream.getVideoTracks().length === 0) {
        for (const t of displayStream.getTracks()) t.stop();
        host.note("No video stream arrived. Please try again.", true);
        host.onFailed();
        return;
      }
      const surface = displayStream.getVideoTracks()[0]?.getSettings().displaySurface;
      if (surface === "browser" || surface === "window") {
        for (const t of displayStream.getTracks()) t.stop();
        host.note(SURFACE_NOT_MONITOR_MSG, true);
        host.onFailed();
        return;
      }
      const videoTrack = displayStream.getVideoTracks()[0];
      videoTrack.onended = () => {
        if (state && state.sessionId === mySessionId) {
          stopInPageRecording();
          return;
        }
        for (const t of displayStream.getTracks()) t.stop();
      };
      let pending = null;
      try {
        const ready = await sendMsgAwait({
          type: "MEET_NUDGE_CAPTURE_READY",
          meetingId: meetingId2 ?? ""
        });
        if (!ready?.ok) {
          for (const t of displayStream.getTracks()) t.stop();
          host.note(friendlyStartError(ready?.error), true);
          host.onFailed();
          return;
        }
        const micStream = await getOptionalMicStream(
          ready.micEnabled !== false,
          ready.micDeviceId ?? ""
        );
        openedMicStream = micStream;
        const audioCtx = new AudioContext({ sampleRate: 48e3 });
        openedAudioCtx = audioCtx;
        const dest = audioCtx.createMediaStreamDestination();
        const pageGain = audioCtx.createGain();
        pageGain.gain.value = TAB_AUDIO_GAIN;
        pageGain.connect(dest);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 2048;
        pending = {
          sessionId: mySessionId,
          recorder: void 0,
          // set below
          audioCtx,
          dest,
          displayStream,
          micStream,
          pageGain,
          systemGain: null,
          analyser,
          taps: /* @__PURE__ */ new Map(),
          rescan: null,
          watchdog: null,
          host
        };
        const tapped = attachPageAudio(pending);
        const hasSystemAudio = displayStream.getAudioTracks().length > 0;
        const usingSystemAudioForClient = tapped === 0 && hasSystemAudio;
        if (tapped === 0) {
          if (!hasSystemAudio) {
            const proceed = await host.confirmWithoutClientAudio();
            if (!proceed) {
              cleanup(pending);
              pending = null;
              sendMsg({ type: "MEET_NUDGE_CANCEL" });
              host.note(NO_CLIENT_AUDIO_MSG, true);
              host.onFailed();
              return;
            }
          }
          clientAudioWaived = true;
        }
        if (micStream && micStream.getAudioTracks().length > 0) {
          audioCtx.createMediaStreamSource(micStream).connect(dest);
        }
        if (usingSystemAudioForClient) {
          const systemGain = audioCtx.createGain();
          systemGain.connect(dest);
          audioCtx.createMediaStreamSource(displayStream).connect(systemGain);
          pending.systemGain = systemGain;
        }
        await audioCtx.resume();
        if (videoTrack.readyState !== "live") {
          cleanup(pending);
          pending = null;
          sendMsg({ type: "MEET_NUDGE_CANCEL" });
          host.note("Screen sharing stopped. Click again to retry.", true);
          host.onFailed();
          return;
        }
        const recordStream = new MediaStream([
          ...displayStream.getVideoTracks(),
          ...dest.stream.getAudioTracks()
        ]);
        const mime = pickMimeType();
        const recorder = new MediaRecorder(recordStream, {
          mimeType: mime,
          videoBitsPerSecond: VIDEO_BITS_PER_SECOND,
          audioBitsPerSecond: AUDIO_BITS_PER_SECOND
        });
        pending.recorder = recorder;
        let chunkIndex = 0;
        let pendingChunks = 0;
        let stopRequested = false;
        const mine = pending;
        const isMine = () => state === mine;
        const retireOrphan = () => {
          try {
            if (mine.recorder.state !== "inactive") mine.recorder.stop();
          } catch {
          }
          cleanup(mine);
        };
        const finishStop = () => {
          if (!isMine()) {
            retireOrphan();
            return;
          }
          cleanup(state);
          state = null;
          sendMsg({ type: "RECORDER_STOPPED", sessionId: mySessionId });
        };
        recorder.ondataavailable = async (event) => {
          if (event.data.size <= 0) {
            if (stopRequested && pendingChunks === 0) finishStop();
            return;
          }
          pendingChunks++;
          try {
            const buffer = await event.data.arrayBuffer();
            if (!isMine()) {
              retireOrphan();
              return;
            }
            const reply = await sendMsgAwait({
              type: "RECORDER_CHUNK",
              chunk: Array.from(new Uint8Array(buffer)),
              index: chunkIndex++,
              mime: recorder.mimeType,
              ts: Date.now(),
              sessionId: mySessionId
            });
            if (reply?.reason === "stale-session") retireOrphan();
          } finally {
            pendingChunks--;
            if (stopRequested && pendingChunks === 0) finishStop();
          }
        };
        recorder.onerror = () => {
          if (!isMine()) {
            retireOrphan();
            return;
          }
          sendMsg({
            type: "RECORDER_ERROR",
            error: "MediaRecorder error",
            sessionId: mySessionId
          });
          cleanup(state);
          state = null;
        };
        recorder.onstop = () => {
          stopRequested = true;
          if (pendingChunks === 0) finishStop();
        };
        const startResp = await sendMsgAwait({
          type: "RECORDER_STARTED",
          mime,
          hasVideo: displayStream.getVideoTracks().length > 0,
          hasAudio: dest.stream.getAudioTracks().length > 0,
          // (F2) Registers THIS session as the owner of the upload the SW is about
          // to create; every later message must carry the same id.
          sessionId: mySessionId
        });
        if (!startResp?.ok) {
          cleanup(pending);
          pending = null;
          host.note(
            `Couldn't start recording: ${startResp?.error ?? "upload session didn't open"}`,
            true
          );
          host.onFailed();
          return;
        }
        state = pending;
        pending = null;
        const rescan = new MutationObserver(() => {
          if (!state) return;
          attachPageAudio(state);
        });
        rescan.observe(document.body, { childList: true, subtree: true });
        state.rescan = rescan;
        const buf = new Float32Array(analyser.fftSize);
        let lastEnergyAt = Date.now();
        let warned = false;
        state.watchdog = setInterval(() => {
          const s = state;
          if (!s || intentionalStop || s.recorder.state === "inactive") return;
          pruneDeadTaps(s);
          const attached = attachPageAudio(s);
          if (attached > 0 && clientAudioWaived) {
            clientAudioWaived = false;
            lastEnergyAt = Date.now();
          }
          const peak = pageAudioPeak(s, buf);
          if (peak > ENERGY_FLOOR) {
            lastEnergyAt = Date.now();
            if (warned) {
              warned = false;
              s.host.note("", false);
            }
            return;
          }
          if (!warned && !clientAudioWaived && Date.now() - lastEnergyAt > SILENCE_WARN_MS) {
            warned = true;
            s.host.note(SILENCE_WARN_MSG, true);
          }
        }, WATCHDOG_TICK_MS);
        recorder.start(200);
        host.onRecordingStarted();
        const micWanted = ready?.micEnabled !== false;
        const micMissing = micWanted && !micStream;
        if (usingSystemAudioForClient) {
          host.note("The other person's audio is being recorded via system audio.", false);
        } else if (clientAudioWaived) {
          host.note(
            "\u26A0\uFE0F Recording without the other person's audio. Stop and re-record with 'Share system audio' enabled.",
            true
          );
        } else if (micMissing) {
          host.note(
            "\u26A0\uFE0F Your microphone isn't being recorded \u2014 permission was denied or not answered. The other person's audio is still captured.",
            true
          );
        }
      } catch (err) {
        const mineNow = pending ?? (state && state.sessionId === mySessionId ? state : null);
        if (mineNow) {
          cleanup(mineNow);
          if (state === mineNow) state = null;
        } else {
          for (const t of displayStream.getTracks()) t.stop();
          if (openedMicStream)
            for (const t of openedMicStream.getTracks()) t.stop();
          openedAudioCtx?.close().catch(() => {
          });
        }
        pending = null;
        sendMsg({
          type: "RECORDER_ERROR",
          error: err instanceof Error ? err.message : String(err),
          sessionId: mySessionId
        });
        host.note(
          `Couldn't start recording: ${err instanceof Error ? err.message : String(err)}`,
          true
        );
        host.onFailed();
      }
    } finally {
      startInFlight = false;
    }
  }

  // src/content/meet-detect.ts
  var meetingId = null;
  var nudgeState = "hidden";
  var laterUntil = 0;
  var dismissed = false;
  var inCall = false;
  var settings = {
    autoRecord: false,
    autoRecordCountdownSec: 5,
    soundEnabled: false
  };
  var countdownTimer = null;
  var countdownRemaining = 0;
  var recordingStartTime = 0;
  var pillPausedAccumMs = 0;
  var elapsedTimer = null;
  var meetEndTimer = null;
  var shadowHost = null;
  var shadowRoot = null;
  var LATER_MS = 12 * 60 * 1e3;
  var MEET_END_DEBOUNCE_MS = 5e3;
  function isMeetingUrl() {
    return /^\/[a-z]+-[a-z]+-[a-z]+/.test(location.pathname);
  }
  function isInMeeting() {
    return !!(document.querySelector('[aria-label="Leave call"]') || document.querySelector('[aria-label*="Leave call"]') || document.querySelector('[data-tooltip="Leave call"]') || document.querySelector('[data-tooltip*="Leave call"]'));
  }
  function currentMeetingId() {
    return getMeetingId(location.href);
  }
  function cancelMeetEnded() {
    if (meetEndTimer !== null) {
      clearTimeout(meetEndTimer);
      meetEndTimer = null;
    }
  }
  function scheduleMeetEnded() {
    if (meetEndTimer !== null) return;
    const id = meetingId;
    meetEndTimer = setTimeout(() => {
      meetEndTimer = null;
      if (!inCall) return;
      if (isMeetingUrl() && isInMeeting()) return;
      inCall = false;
      if (id) sendToBackground({ type: "MEET_CALL_ENDED", meetingId: id });
      stopCountdown();
      if (elapsedTimer !== null) {
        clearInterval(elapsedTimer);
        elapsedTimer = null;
      }
      if (nudgeState !== "recording") {
        clearNudge();
        nudgeState = "hidden";
      }
    }, MEET_END_DEBOUNCE_MS);
  }
  function sineNode(ctx, freq, t, startOffset, dur, vol) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, t + startOffset);
    gain.gain.setValueAtTime(0, t + startOffset);
    gain.gain.linearRampToValueAtTime(vol, t + startOffset + 8e-3);
    gain.gain.exponentialRampToValueAtTime(1e-3, t + startOffset + dur);
    osc.start(t + startOffset);
    osc.stop(t + startOffset + dur);
  }
  function soundDroplet(ctx, t) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(1700, t);
    osc.frequency.exponentialRampToValueAtTime(360, t + 0.11);
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.12, t + 5e-3);
    gain.gain.exponentialRampToValueAtTime(1e-3, t + 0.36);
    osc.start(t);
    osc.stop(t + 0.28);
  }
  function soundChime(ctx, t) {
    sineNode(ctx, 880, t, 0, 0.38, 0.12);
    sineNode(ctx, 1318, t, 0.16, 0.5, 0.1);
  }
  function playAudio(fn) {
    if (!settings.soundEnabled) return;
    try {
      const ctx = new AudioContext();
      const play = () => {
        fn(ctx, ctx.currentTime);
        setTimeout(() => ctx.close().catch(() => {
        }), 1500);
      };
      if (ctx.state === "suspended") {
        ctx.resume().then(play).catch(() => {
        });
      } else {
        play();
      }
    } catch (_) {
    }
  }
  var NUDGE_CSS = `
:host { all: initial; }

.cap-nudge-container {
	position: fixed;
	top: 16px;
	left: 50%;
	transform: translateX(-50%);
	z-index: 2147483647;
	font-family: system-ui, sans-serif;
	font-size: 14px;
	color: #1a1a1a;
	pointer-events: all;
	user-select: none;
}

@keyframes cap-nudge-in {
	from { opacity: 0; transform: translateY(-12px); }
	to   { opacity: 1; transform: translateY(0); }
}

@keyframes cap-nudge-out {
	from { opacity: 1; transform: translateY(0); }
	to   { opacity: 0; transform: translateY(-8px); }
}

@keyframes cap-nudge-pulse {
	0%, 100% { box-shadow: 0 0 0 0 rgba(239,68,68,.65); }
	55%       { box-shadow: 0 0 0 6px rgba(239,68,68,0); }
}

.cap-nudge-card {
	background: #ffffff;
	border-radius: 12px;
	box-shadow: 0 8px 24px rgba(0,0,0,0.18);
	padding: 16px;
	width: 320px;
	box-sizing: border-box;
	animation: cap-nudge-in .25s cubic-bezier(.2,.8,.4,1) both;
}

.cap-nudge-card.cap-nudge-leaving { animation: cap-nudge-out .2s ease-in both; }

.cap-nudge-title {
	font-weight: 700;
	font-size: 15px;
	margin: 0 0 4px 0;
	color: #111;
}

.cap-nudge-subtitle {
	font-size: 12px;
	color: #666;
	margin: 0 0 14px 0;
}

.cap-nudge-buttons {
	display: flex;
	gap: 8px;
	align-items: center;
}

.cap-nudge-btn-primary {
	background: #675FFF;
	color: #fff;
	border: none;
	border-radius: 8px;
	padding: 8px 16px;
	font-size: 13px;
	font-weight: 600;
	cursor: pointer;
	font-family: inherit;
	transition: filter .15s, transform .1s, outline .1s;
	white-space: nowrap;
}

.cap-nudge-btn-primary:hover { filter: brightness(1.1); }

.cap-nudge-btn-primary:active {
	transform: scale(0.97);
	opacity: 0.85;
}

.cap-nudge-btn-primary:focus-visible {
	outline: 2px solid #6366f1;
	outline-offset: 2px;
}

.cap-nudge-btn-secondary {
	background: #f3f4f6;
	color: #374151;
	border: none;
	border-radius: 8px;
	padding: 8px 14px;
	font-size: 13px;
	font-weight: 500;
	cursor: pointer;
	font-family: inherit;
	transition: background .15s, transform .1s, outline .1s;
	white-space: nowrap;
}

.cap-nudge-btn-secondary:hover { background: #e5e7eb; }

.cap-nudge-btn-secondary:active {
	transform: scale(0.97);
	opacity: 0.85;
}

.cap-nudge-btn-secondary:focus-visible {
	outline: 2px solid #6366f1;
	outline-offset: 2px;
}

.cap-nudge-btn-dismiss {
	background: transparent;
	border: none;
	color: #9ca3af;
	font-size: 12px;
	cursor: pointer;
	font-family: inherit;
	padding: 4px 8px;
	text-decoration: underline;
	white-space: nowrap;
	transition: color .15s, opacity .1s;
}

.cap-nudge-btn-dismiss:hover { color: #6b7280; }

.cap-nudge-btn-dismiss:active { opacity: 0.5; }

.cap-nudge-btn-cancel {
	display: block;
	width: 100%;
	background: #f3f4f6;
	color: #374151;
	border: none;
	border-radius: 8px;
	padding: 9px 0;
	font-size: 13px;
	font-weight: 600;
	cursor: pointer;
	font-family: inherit;
	margin-bottom: 8px;
	transition: background .15s;
}

.cap-nudge-btn-cancel:hover { background: #e5e7eb; }

.cap-nudge-no-auto {
	display: block;
	text-align: center;
	background: transparent;
	border: none;
	color: #9ca3af;
	font-size: 11px;
	cursor: pointer;
	font-family: inherit;
	text-decoration: underline;
}

.cap-nudge-no-auto:hover { color: #6b7280; }

.cap-nudge-live-note {
	margin-top: 8px;
	max-width: 320px;
	background: #111827;
	color: #f9fafb;
	border-radius: 8px;
	padding: 8px 12px;
	font-size: 12px;
	line-height: 1.35;
	box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.cap-nudge-live-note-error { color: #fca5a5; }

.cap-nudge-confirm {
	margin-top: 12px;
	padding-top: 12px;
	border-top: 1px solid #e5e7eb;
}

.cap-nudge-pill {
	background: #111827;
	border-radius: 999px;
	padding: 8px 14px;
	display: inline-flex;
	align-items: center;
	gap: 10px;
	box-shadow: 0 4px 12px rgba(0,0,0,0.15);
	animation: cap-nudge-in .25s cubic-bezier(.2,.8,.4,1) both;
}

.cap-nudge-pill.cap-nudge-leaving { animation: cap-nudge-out .2s ease-in both; }

.cap-nudge-dot {
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: #ef4444;
	flex-shrink: 0;
	animation: cap-nudge-pulse 1.9s ease-out infinite;
}

.cap-nudge-elapsed {
	font-size: 13px;
	font-weight: 600;
	color: #f9fafb;
	font-variant-numeric: tabular-nums;
	min-width: 52px;
}

.cap-nudge-paused-label {
	font-size: 11px;
	color: #9ca3af;
}

.cap-nudge-btn-stop {
	background: #ef4444;
	color: #fff;
	border: none;
	border-radius: 6px;
	padding: 4px 10px;
	font-size: 12px;
	font-weight: 600;
	cursor: pointer;
	font-family: inherit;
	transition: filter .15s, transform .1s, outline .1s;
}

.cap-nudge-btn-stop:hover { filter: brightness(1.1); }

.cap-nudge-btn-stop:active {
	transform: scale(0.97);
	opacity: 0.85;
}

.cap-nudge-btn-stop:focus-visible {
	outline: 2px solid #6366f1;
	outline-offset: 2px;
}

.cap-nudge-progress {
	font-size: 11px;
	color: #9ca3af;
	margin-left: 4px;
}

.cap-nudge-complete-card {
	background: #ffffff;
	border-radius: 12px;
	box-shadow: 0 8px 24px rgba(0,0,0,0.18);
	padding: 16px;
	width: 320px;
	box-sizing: border-box;
	animation: cap-nudge-in .25s cubic-bezier(.2,.8,.4,1) both;
}

.cap-nudge-complete-card.cap-nudge-leaving { animation: cap-nudge-out .2s ease-in both; }

.cap-nudge-complete-check {
	font-size: 28px;
	color: #38a169;
	margin: 0 0 4px 0;
}

.cap-nudge-share-url {
	font-size: 11px;
	color: #666;
	word-break: break-all;
	margin: 4px 0 10px 0;
}

.cap-nudge-btn-copy {
	background: #675FFF;
	color: #fff;
	border: none;
	border-radius: 8px;
	padding: 7px 14px;
	font-size: 12px;
	font-weight: 600;
	cursor: pointer;
	font-family: inherit;
	transition: filter .15s, transform .1s, outline .1s;
	white-space: nowrap;
}

.cap-nudge-btn-copy:hover { filter: brightness(1.1); }

.cap-nudge-btn-copy:active {
	transform: scale(0.97);
	opacity: 0.85;
}

.cap-nudge-btn-copy:focus-visible {
	outline: 2px solid #6366f1;
	outline-offset: 2px;
}

.cap-nudge-btn-open {
	background: #f3f4f6;
	color: #374151;
	border: none;
	border-radius: 8px;
	padding: 7px 14px;
	font-size: 12px;
	font-weight: 500;
	cursor: pointer;
	font-family: inherit;
	transition: background .15s;
	white-space: nowrap;
}

.cap-nudge-btn-open:hover { background: #e5e7eb; }

.cap-nudge-error-card {
	background: #ffffff;
	border-radius: 12px;
	box-shadow: 0 4px 24px rgba(0,0,0,.18), 0 1px 4px rgba(0,0,0,.08);
	padding: 16px;
	width: 320px;
	box-sizing: border-box;
	animation: cap-nudge-in .25s cubic-bezier(.2,.8,.4,1) both;
}

.cap-nudge-error-card.cap-nudge-leaving { animation: cap-nudge-out .2s ease-in both; }

.cap-nudge-error-msg {
	font-size: 12px;
	color: #e53e3e;
	margin: 4px 0 10px 0;
}
`;
  function ensureShadowRoot() {
    if (shadowRoot) return shadowRoot;
    shadowHost = document.createElement("div");
    shadowHost.id = "cap-nudge-host";
    document.body.appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = NUDGE_CSS;
    shadowRoot.appendChild(style);
    const container = document.createElement("div");
    container.className = "cap-nudge-container";
    container.id = "cap-nudge-container";
    shadowRoot.appendChild(container);
    return shadowRoot;
  }
  function getNudgeContainer() {
    if (!shadowRoot) return null;
    return shadowRoot.getElementById("cap-nudge-container");
  }
  function clearNudge(onRemoved) {
    const container = getNudgeContainer();
    if (!container || !container.firstChild) {
      onRemoved?.();
      return;
    }
    const child = container.firstChild;
    child.classList.add("cap-nudge-leaving");
    setTimeout(() => {
      child.remove();
      onRemoved?.();
    }, 190);
  }
  function makeEl(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text) el.textContent = text;
    return el;
  }
  function makeBtn(className, text) {
    const btn = document.createElement("button");
    btn.className = className;
    btn.textContent = text;
    return btn;
  }
  function formatElapsed(ms) {
    const totalSec = Math.floor(ms / 1e3);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor(totalSec % 3600 / 60);
    const s = totalSec % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
  }
  function confirmWithoutClientAudioInCard(card) {
    return new Promise((resolve) => {
      const existing = card.querySelector(".cap-nudge-confirm");
      if (existing) existing.remove();
      const box = makeEl("div", "cap-nudge-confirm");
      const msg = makeEl(
        "div",
        "cap-nudge-subtitle",
        "The other person's audio wasn't captured \u2014 'Share system audio' isn't enabled. Cancel, record again, and turn it on. Record without it anyway?"
      );
      const buttons = makeEl("div", "cap-nudge-buttons");
      const yes = makeBtn("cap-nudge-btn-primary", "Start anyway");
      const no = makeBtn("cap-nudge-btn-secondary", "Cancel");
      buttons.append(yes, no);
      box.append(msg, buttons);
      card.appendChild(box);
      const finish = (proceed) => {
        box.remove();
        resolve(proceed);
      };
      yes.addEventListener("click", () => finish(true), { once: true });
      no.addEventListener("click", () => finish(false), { once: true });
    });
  }
  function renderDefaultNudge() {
    const root = ensureShadowRoot();
    const container = root.getElementById("cap-nudge-container");
    if (!container) return;
    container.textContent = "";
    const card = makeEl("div", "cap-nudge-card");
    const title = makeEl("div", "cap-nudge-title", "Record this meeting?");
    const subtitle = makeEl(
      "div",
      "cap-nudge-subtitle",
      "When the screen picker opens, choose 'Entire Screen' and turn on 'Share system audio' \u2014 that's how the other person's voice gets recorded."
    );
    const buttons = makeEl("div", "cap-nudge-buttons");
    const btnRecord = makeBtn("cap-nudge-btn-primary", "Record now");
    const btnLater = makeBtn("cap-nudge-btn-secondary", "Later");
    const btnDismiss = makeBtn("cap-nudge-btn-dismiss", "Close");
    buttons.append(btnRecord, btnLater, btnDismiss);
    card.append(title, subtitle, buttons);
    container.appendChild(card);
    nudgeState = "default";
    btnRecord.addEventListener("click", (event) => {
      event.stopImmediatePropagation();
      btnRecord.disabled = true;
      btnRecord.textContent = "Starting\u2026";
      void startInPageRecording(meetingId, {
        note: (text, isError) => showLiveNote(text, isError),
        confirmWithoutClientAudio: () => confirmWithoutClientAudioInCard(card),
        onRecordingStarted: () => {
          recordingStartTime = Date.now();
          pillPausedAccumMs = 0;
          clearNudge(() => renderRecordingPill(false));
        },
        onFailed: () => {
          btnRecord.disabled = false;
          btnRecord.textContent = "Record now";
        }
      });
    });
    btnLater.addEventListener("click", () => {
      sendToBackground({ type: "MEET_NUDGE_LATER" });
      laterUntil = Date.now() + LATER_MS;
      clearNudge();
      nudgeState = "hidden";
    });
    btnDismiss.addEventListener("click", () => {
      sendToBackground({ type: "MEET_NUDGE_DISMISS" });
      dismissed = true;
      clearNudge();
      nudgeState = "hidden";
    });
  }
  function renderCountdownNudge() {
    const root = ensureShadowRoot();
    const container = root.getElementById("cap-nudge-container");
    if (!container) return;
    container.textContent = "";
    countdownRemaining = settings.autoRecordCountdownSec;
    const card = makeEl("div", "cap-nudge-card");
    const titleEl = makeEl("div", "cap-nudge-title");
    const titleText = document.createTextNode("Starting recording in ");
    const numSpan = makeEl("span", void 0, String(countdownRemaining));
    const titleSuffix = document.createTextNode("s");
    titleEl.append(titleText, numSpan, titleSuffix);
    const btnCancel = makeBtn("cap-nudge-btn-cancel", "Cancel");
    const btnNoAuto = makeBtn(
      "cap-nudge-no-auto",
      "Don\u2019t auto-record this meeting"
    );
    card.append(titleEl, btnCancel, btnNoAuto);
    container.appendChild(card);
    nudgeState = "countdown";
    const onCancel = () => {
      stopCountdown();
      sendToBackground({ type: "MEET_NUDGE_DISMISS" });
      dismissed = true;
      clearNudge();
      nudgeState = "hidden";
    };
    btnCancel.addEventListener("click", onCancel);
    btnNoAuto.addEventListener("click", onCancel);
    countdownTimer = setInterval(() => {
      countdownRemaining -= 1;
      numSpan.textContent = String(countdownRemaining);
      if (countdownRemaining <= 0) {
        stopCountdown();
        playAudio(soundChime);
        renderDefaultNudge();
        const activeCard = getNudgeContainer()?.querySelector(
          ".cap-nudge-card"
        );
        if (activeCard) {
          showStartNote(
            activeCard,
            'Press "Record now" to start \u2014 the screen picker opens right away.',
            false
          );
        }
      }
    }, 1e3);
  }
  function stopCountdown() {
    if (countdownTimer !== null) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
  }
  function renderRecordingPill(paused = false) {
    const root = ensureShadowRoot();
    const container = root.getElementById("cap-nudge-container");
    if (!container) return;
    const liveNote = container.querySelector(".cap-nudge-live-note");
    container.textContent = "";
    if (recordingStartTime === 0) recordingStartTime = Date.now();
    const pill = makeEl("div", "cap-nudge-pill");
    const dot = makeEl("span", "cap-nudge-dot");
    const elapsed = makeEl(
      "span",
      "cap-nudge-elapsed",
      formatElapsed(Date.now() - recordingStartTime - pillPausedAccumMs)
    );
    elapsed.id = "cap-elapsed";
    const btnStop = makeBtn("cap-nudge-btn-stop", "Stop");
    if (paused) {
      const pausedLabel = makeEl("span", "cap-nudge-paused-label", "Paused");
      pill.append(dot, elapsed, pausedLabel, btnStop);
    } else {
      pill.append(dot, elapsed, btnStop);
    }
    container.appendChild(pill);
    if (liveNote) container.appendChild(liveNote);
    nudgeState = "recording";
    if (elapsedTimer !== null) clearInterval(elapsedTimer);
    if (!paused) {
      elapsedTimer = setInterval(() => {
        const el = container.querySelector("#cap-elapsed");
        if (el)
          el.textContent = formatElapsed(
            Date.now() - recordingStartTime - pillPausedAccumMs
          );
      }, 1e3);
    }
    btnStop.addEventListener("click", () => {
      sendToBackground({ type: "STOP" });
    });
  }
  function renderFinishingPill() {
    const root = ensureShadowRoot();
    const container = root.getElementById("cap-nudge-container");
    if (!container) return;
    container.textContent = "";
    if (elapsedTimer !== null) {
      clearInterval(elapsedTimer);
      elapsedTimer = null;
    }
    const pill = makeEl("div", "cap-nudge-pill");
    const dot = makeEl("span", "cap-nudge-dot");
    dot.style.background = "#3182ce";
    dot.style.animation = "none";
    const label = makeEl("span", "cap-nudge-elapsed", "Finishing up...");
    pill.append(dot, label);
    container.appendChild(pill);
    nudgeState = "finishing";
  }
  function renderCompletePill(shareUrl) {
    const root = ensureShadowRoot();
    const container = root.getElementById("cap-nudge-container");
    if (!container) return;
    container.textContent = "";
    if (elapsedTimer !== null) {
      clearInterval(elapsedTimer);
      elapsedTimer = null;
    }
    recordingStartTime = 0;
    const card = makeEl("div", "cap-nudge-complete-card");
    const check = makeEl("div", "cap-nudge-complete-check", "\u2713");
    const title = makeEl("div", "cap-nudge-title", "Recording saved!");
    const urlEl = makeEl("div", "cap-nudge-share-url", shareUrl);
    const buttons = makeEl("div", "cap-nudge-buttons");
    const copyBtn = makeBtn("cap-nudge-btn-copy", "Copy link");
    const openBtn = makeBtn("cap-nudge-btn-open", "Open");
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(shareUrl).then(() => {
        copyBtn.textContent = "Copied!";
        setTimeout(() => {
          copyBtn.textContent = "Copy link";
        }, 2e3);
      });
    });
    openBtn.addEventListener("click", () => {
      window.open(shareUrl, "_blank");
    });
    const dismissBtn = makeBtn("cap-nudge-btn-dismiss", "Close");
    dismissBtn.addEventListener("click", () => {
      sendToBackground({ type: "CANCEL" });
      clearNudge();
      nudgeState = "hidden";
    });
    buttons.append(copyBtn, openBtn);
    card.append(check, title, urlEl, buttons, dismissBtn);
    container.appendChild(card);
    nudgeState = "complete";
  }
  function renderErrorCard(reason, recoverable) {
    const root = ensureShadowRoot();
    const container = root.getElementById("cap-nudge-container");
    if (!container) return;
    container.textContent = "";
    if (elapsedTimer !== null) {
      clearInterval(elapsedTimer);
      elapsedTimer = null;
    }
    recordingStartTime = 0;
    const card = makeEl("div", "cap-nudge-error-card");
    const title = makeEl("div", "cap-nudge-title", "Upload failed");
    const msg = makeEl("div", "cap-nudge-error-msg", reason);
    const buttons = makeEl("div", "cap-nudge-buttons");
    if (recoverable) {
      const retryBtn = makeBtn("cap-nudge-btn-primary", "Retry");
      retryBtn.addEventListener("click", () => {
        sendToBackground({ type: "RETRY" });
      });
      buttons.appendChild(retryBtn);
    }
    const dismissBtn = makeBtn("cap-nudge-btn-secondary", "Close");
    dismissBtn.addEventListener("click", () => {
      sendToBackground({ type: "CANCEL" });
      clearNudge();
      nudgeState = "hidden";
    });
    buttons.appendChild(dismissBtn);
    card.append(title, msg, buttons);
    container.appendChild(card);
    nudgeState = "error";
  }
  function sendToBackground(msg) {
    chrome.runtime.sendMessage(msg).catch(() => {
    });
  }
  function showLiveNote(text, isError) {
    const container = getNudgeContainer();
    if (!container) return;
    const existing = container.querySelector(
      ".cap-nudge-live-note"
    );
    if (!text) {
      existing?.remove();
      return;
    }
    const note = existing ?? makeEl("div", "cap-nudge-live-note");
    note.classList.toggle("cap-nudge-live-note-error", isError);
    note.textContent = text;
    if (!existing) container.appendChild(note);
  }
  function showStartNote(card, text, isError) {
    const existing = card.querySelector(
      ".cap-nudge-send-err"
    );
    const note = existing ?? document.createElement("p");
    note.className = "cap-nudge-send-err";
    note.style.cssText = isError ? "font-size:12px;color:#e53e3e;margin:6px 0 0;" : "font-size:12px;color:#6b7280;margin:6px 0 0;";
    note.textContent = text;
    if (!existing) card.appendChild(note);
  }
  function maybeShow() {
    if (!isMeetingUrl() || !isInMeeting()) {
      if (inCall) {
        scheduleMeetEnded();
      }
      return;
    }
    cancelMeetEnded();
    const id = currentMeetingId();
    if (id !== meetingId) {
      cancelMeetEnded();
      meetingId = id;
      dismissed = false;
      laterUntil = 0;
      inCall = false;
      stopCountdown();
      if (elapsedTimer !== null) {
        clearInterval(elapsedTimer);
        elapsedTimer = null;
      }
      recordingStartTime = 0;
      clearNudge();
      nudgeState = "hidden";
    }
    if (!inCall) {
      inCall = true;
      if (meetingId) sendToBackground({ type: "MEET_CALL_STARTED", meetingId });
      playAudio(soundDroplet);
    }
    if (nudgeState === "recording" || nudgeState === "countdown" || nudgeState === "finishing" || nudgeState === "complete" || nudgeState === "error")
      return;
    if (dismissed || nudgeState === "default" || Date.now() < laterUntil) return;
    if (settings.autoRecord) {
      renderCountdownNudge();
    } else {
      renderDefaultNudge();
    }
  }
  function handleStateChange(state2) {
    switch (state2.kind) {
      case "recording":
        stopCountdown();
        if (recordingStartTime === 0) {
          recordingStartTime = state2.startedAt ?? Date.now();
        }
        pillPausedAccumMs = state2.pausedAccumMs ?? 0;
        clearNudge(() => renderRecordingPill(state2.paused ?? false));
        break;
      case "uploading":
      case "finishing":
        clearNudge(() => renderFinishingPill());
        break;
      case "complete":
        if (state2.shareUrl) {
          clearNudge(() => renderCompletePill(state2.shareUrl));
        }
        break;
      case "error":
        clearNudge(
          () => renderErrorCard(
            state2.reason ?? "Unknown error",
            state2.recoverable ?? false
          )
        );
        break;
      case "idle":
        if (elapsedTimer !== null) {
          clearInterval(elapsedTimer);
          elapsedTimer = null;
        }
        recordingStartTime = 0;
        clearNudge();
        nudgeState = "hidden";
        if (isInMeeting()) {
          dismissed = false;
          setTimeout(maybeShow, 800);
        }
        break;
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== "object") return;
    const message = msg;
    if (message.type === "STATE_CHANGED" && message.state) {
      handleStateChange(message.state);
      return;
    }
    if (message.type === "IS_INPAGE_RECORDING") {
      sendResponse({ recording: isInPageRecording() });
      return;
    }
    if (message.type === "STOP_CAPTURE") {
      if (isInPageRecording()) {
        stopInPageRecording();
        sendResponse({ ok: true });
      }
    } else if (message.type === "PAUSE_CAPTURE") {
      if (isInPageRecording()) {
        pauseInPageRecording();
        sendResponse({ ok: true });
      }
    } else if (message.type === "RESUME_CAPTURE") {
      if (isInPageRecording()) {
        resumeInPageRecording();
        sendResponse({ ok: true });
      }
    }
  });
  window.addEventListener("beforeunload", () => {
    if (isInPageRecording()) stopInPageRecording();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.capExtState?.newValue) {
      handleStateChange(
        changes.capExtState.newValue
      );
    }
  });
  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }).then((resp) => {
    if (resp && typeof resp === "object") {
      const r = resp;
      if (typeof r.autoRecord === "boolean") settings.autoRecord = r.autoRecord;
      if (typeof r.autoRecordCountdownSec === "number")
        settings.autoRecordCountdownSec = r.autoRecordCountdownSec;
      if (typeof r.soundEnabled === "boolean")
        settings.soundEnabled = r.soundEnabled;
    }
    maybeShow();
  }).catch(() => {
    maybeShow();
  });
  var lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      maybeShow();
    }
  }, 1e3);
  window.addEventListener("popstate", maybeShow);
  window.addEventListener("hashchange", maybeShow);
  var mutationDebounce = null;
  var observer = new MutationObserver(() => {
    if (mutationDebounce !== null) clearTimeout(mutationDebounce);
    mutationDebounce = setTimeout(maybeShow, 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();
//# sourceMappingURL=content.js.map
