// src/shared/client-audio.ts
var TAB_AUDIO_PROBLEM = {
  missing: "the tab isn't exposing any audio",
  ended: "the tab's audio stopped",
  muted: "the tab is muted in Chrome (right-click the tab \u2192 Unmute site)"
};
function tabAudioStatus(track) {
  if (!track) return "missing";
  if (track.readyState !== "live") return "ended";
  if (track.muted) return "muted";
  return "live";
}
function isTabAudioLive(track) {
  return tabAudioStatus(track) === "live";
}

// src/shared/recording-quality.ts
var VIDEO_BITS_PER_SECOND = 3e6;
var AUDIO_BITS_PER_SECOND = 128e3;
var TAB_AUDIO_GAIN = 1.8;
function pickMimeType() {
  const candidates = [
    "video/mp4;codecs=h264",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return "video/webm";
}

// src/shared/recorder-session.ts
function newSessionId() {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  return `rs-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

// src/offscreen/recorder.ts
var state = null;
var MIC_ACQUIRE_TIMEOUT_MS = 8e3;
function withTimeout(p, ms) {
  let settled = false;
  const guarded = p.then((stream) => {
    if (settled) {
      for (const t of stream.getTracks()) t.stop();
      return null;
    }
    return stream;
  }).catch(() => null);
  return Promise.race([
    guarded,
    new Promise(
      (resolve) => setTimeout(() => {
        settled = true;
        resolve(null);
      }, ms)
    )
  ]);
}
function noClientAudioError(problem) {
  return new Error(
    `Can't record this meeting: ${problem}, so the other participants wouldn't be recorded. Unmute the tab and try again, or use "Record full-screen meeting".`
  );
}
function sendMsg(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
  });
}
function sendMsgAwait(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}
function cleanup(s) {
  for (const t of s.displayStream.getTracks()) t.stop();
  if (s.micStream) for (const t of s.micStream.getTracks()) t.stop();
  s.audioCtx.close().catch(() => {
  });
}
async function startCapture(msg) {
  if (state) {
    cleanup(state);
    state = null;
  }
  const mySessionId = newSessionId();
  try {
    if (!msg.streamId) throw new Error("streamId required for tab capture");
    let displayStream;
    try {
      displayStream = await navigator.mediaDevices.getUserMedia({
        video: {
          mandatory: {
            chromeMediaSource: "tab",
            chromeMediaSourceId: msg.streamId
          }
        },
        audio: {
          mandatory: {
            chromeMediaSource: "tab",
            chromeMediaSourceId: msg.streamId
          }
        }
      });
    } catch (err) {
      throw noClientAudioError(
        `${TAB_AUDIO_PROBLEM.missing} (${err instanceof Error ? err.message : String(err)})`
      );
    }
    const startStatus = tabAudioStatus(displayStream.getAudioTracks()[0]);
    if (startStatus !== "live") {
      for (const t of displayStream.getTracks()) t.stop();
      throw noClientAudioError(TAB_AUDIO_PROBLEM[startStatus]);
    }
    let micStream = null;
    if (msg.micEnabled !== false) {
      micStream = await withTimeout(
        navigator.mediaDevices.getUserMedia({
          audio: msg.micDeviceId ? { deviceId: { exact: msg.micDeviceId } } : true
        }),
        MIC_ACQUIRE_TIMEOUT_MS
      );
      if (!micStream) {
        micStream = await withTimeout(
          navigator.mediaDevices.getUserMedia({ audio: true }),
          MIC_ACQUIRE_TIMEOUT_MS
        );
      }
    }
    const audioCtx = new AudioContext({ sampleRate: 48e3 });
    const dest = audioCtx.createMediaStreamDestination();
    if (displayStream.getAudioTracks().length > 0) {
      const displaySrc = audioCtx.createMediaStreamSource(displayStream);
      const tabGain = audioCtx.createGain();
      tabGain.gain.value = TAB_AUDIO_GAIN;
      displaySrc.connect(tabGain).connect(dest);
      displaySrc.connect(audioCtx.destination);
    }
    if (micStream && micStream.getAudioTracks().length > 0) {
      audioCtx.createMediaStreamSource(micStream).connect(dest);
    }
    const recordStream = new MediaStream([
      ...displayStream.getVideoTracks(),
      ...dest.stream.getAudioTracks()
    ]);
    const mime = pickMimeType();
    const recorder = new MediaRecorder(recordStream, {
      mimeType: mime,
      videoBitsPerSecond: VIDEO_BITS_PER_SECOND,
      audioBitsPerSecond: AUDIO_BITS_PER_SECOND
    });
    let chunkIndex = 0;
    let pendingChunks = 0;
    let stopRequested = false;
    const isMine = () => state !== null && state.sessionId === mySessionId;
    const retireOrphan = () => {
      try {
        if (recorder.state !== "inactive") recorder.stop();
      } catch {
      }
      for (const t of displayStream.getTracks()) t.stop();
      if (micStream) for (const t of micStream.getTracks()) t.stop();
      audioCtx.close().catch(() => {
      });
    };
    const finishStop = () => {
      if (!isMine()) {
        retireOrphan();
        return;
      }
      if (state) {
        cleanup(state);
        state = null;
      }
      sendMsg({ type: "RECORDER_STOPPED", sessionId: mySessionId });
    };
    recorder.ondataavailable = async (e) => {
      if (e.data.size <= 0) {
        if (stopRequested && pendingChunks === 0) finishStop();
        return;
      }
      pendingChunks++;
      try {
        const buffer = await e.data.arrayBuffer();
        if (!isMine()) {
          retireOrphan();
          return;
        }
        const reply = await sendMsgAwait({
          type: "RECORDER_CHUNK",
          chunk: Array.from(new Uint8Array(buffer)),
          index: chunkIndex++,
          mime: recorder.mimeType,
          ts: Date.now(),
          sessionId: mySessionId
        });
        if (reply?.reason === "stale-session") retireOrphan();
      } finally {
        pendingChunks--;
        if (stopRequested && pendingChunks === 0) finishStop();
      }
    };
    recorder.onerror = () => {
      if (!isMine()) {
        retireOrphan();
        return;
      }
      sendMsg({
        type: "RECORDER_ERROR",
        error: "MediaRecorder error",
        sessionId: mySessionId
      });
      if (state) {
        cleanup(state);
        state = null;
      }
    };
    recorder.onstop = () => {
      stopRequested = true;
      if (pendingChunks === 0) finishStop();
    };
    const videoTracks = displayStream.getVideoTracks();
    if (videoTracks.length > 0) {
      videoTracks[0].onended = () => {
        if (state && state.recorder.state !== "inactive") {
          state.recorder.stop();
        }
      };
    }
    state = {
      sessionId: mySessionId,
      recorder,
      audioCtx,
      displayStream,
      micStream,
      chunkIndex
    };
    const tabAudioTrack = displayStream.getAudioTracks()[0];
    if (tabAudioTrack) {
      const isThisRecording = () => state?.displayStream === displayStream;
      tabAudioTrack.onmute = () => {
        setTimeout(() => {
          if (isThisRecording() && state?.recorder.state !== void 0 && state.recorder.state !== "inactive" && !isTabAudioLive(tabAudioTrack)) {
            sendMsg({ type: "TAB_AUDIO_DEGRADED", cause: "muted" });
          }
        }, 1500);
      };
      tabAudioTrack.onunmute = () => {
        if (isThisRecording() && state?.recorder.state !== "inactive" && isTabAudioLive(tabAudioTrack)) {
          sendMsg({ type: "TAB_AUDIO_RECOVERED" });
        }
      };
    }
    const startResp = await sendMsgAwait({
      type: "RECORDER_STARTED",
      mime,
      hasVideo: displayStream.getVideoTracks().length > 0,
      hasAudio: dest.stream.getAudioTracks().length > 0,
      // (F2) Registers THIS session as the owner of the upload.
      sessionId: mySessionId
    });
    if (!startResp?.ok) {
      if (state && state.sessionId === mySessionId) {
        cleanup(state);
        state = null;
      }
      sendMsg({
        type: "RECORDER_ERROR",
        error: startResp?.error ?? "Couldn't start the upload session.",
        sessionId: mySessionId
      });
      return;
    }
    recorder.start(200);
  } catch (err) {
    sendMsg({
      type: "RECORDER_ERROR",
      error: err instanceof Error ? err.message : String(err),
      sessionId: mySessionId
    });
    if (state && state.sessionId === mySessionId) {
      cleanup(state);
      state = null;
    }
  }
}
chrome.runtime.onMessage.addListener((raw, _sender, sendResponse) => {
  const msg = raw;
  if (msg.type === "START_CAPTURE") {
    startCapture(msg).catch((err) => {
      sendMsg({
        type: "RECORDER_ERROR",
        error: err instanceof Error ? err.message : String(err)
      });
    });
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "STOP_CAPTURE") {
    if (!state) {
      sendResponse({ ok: true });
      return;
    }
    if (state.recorder.state !== "inactive") {
      state.recorder.stop();
    } else {
      const sessionId = state.sessionId;
      cleanup(state);
      state = null;
      sendMsg({ type: "RECORDER_STOPPED", sessionId });
    }
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "PAUSE_CAPTURE") {
    if (state && state.recorder.state === "recording") {
      state.recorder.pause();
      sendResponse({ ok: true });
    }
    return;
  }
  if (msg.type === "RESUME_CAPTURE") {
    if (state && state.recorder.state === "paused") {
      state.recorder.resume();
      sendResponse({ ok: true });
    }
    return;
  }
});
//# sourceMappingURL=offscreen.js.map
