// src/shared/config.ts
var extensionEnv = globalThis.process?.env;
var fallbackApiBaseUrl = "https://data365.duckdns.org";
var DEFAULT_API_BASE_URL = [
  extensionEnv?.EXTENSION_API_BASE_URL,
  extensionEnv?.WEB_URL,
  extensionEnv?.NEXT_PUBLIC_WEB_URL,
  fallbackApiBaseUrl
].map((value) => value?.trim()).find((value) => Boolean(value)) ?? fallbackApiBaseUrl;

// src/options/options.ts
function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
async function loadSettings() {
  const response = await sendMessage({ type: "GET_ALL_SETTINGS" });
  return response;
}
async function saveSettings(settings) {
  await sendMessage({ type: "SAVE_SETTINGS", settings });
}
function showToast(message) {
  const existing = document.getElementById("cap-toast");
  if (existing) existing.remove();
  const toast = document.createElement("div");
  toast.id = "cap-toast";
  toast.className = "toast";
  toast.textContent = message;
  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("toast--visible");
  });
  setTimeout(() => {
    toast.classList.remove("toast--visible");
    setTimeout(() => toast.remove(), 300);
  }, 2e3);
}
function createToggle(id, checked) {
  const label = document.createElement("label");
  label.className = "toggle";
  label.htmlFor = id;
  const input = document.createElement("input");
  input.type = "checkbox";
  input.id = id;
  input.checked = checked;
  const track = document.createElement("span");
  track.className = "toggle__track";
  const knob = document.createElement("span");
  knob.className = "toggle__knob";
  track.appendChild(knob);
  label.appendChild(input);
  label.appendChild(track);
  return label;
}
function fieldGroup(labelText, control, description) {
  const group = document.createElement("div");
  group.className = "field-group";
  const label = document.createElement("label");
  label.className = "field-label";
  label.textContent = labelText;
  if (control.id) label.htmlFor = control.id;
  group.appendChild(label);
  group.appendChild(control);
  if (description) {
    const desc = document.createElement("p");
    desc.className = "field-description";
    desc.textContent = description;
    group.appendChild(desc);
  }
  return group;
}
function sectionHeader(text) {
  const h2 = document.createElement("h2");
  h2.className = "section-header";
  h2.textContent = text;
  return h2;
}
function divider() {
  const hr = document.createElement("hr");
  hr.className = "section-divider";
  return hr;
}
async function populateMicrophoneSelect(select, currentDeviceId) {
  try {
    await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "Mikrofonga ruxsat berilmadi";
    select.appendChild(opt);
    return;
  }
  const devices = await navigator.mediaDevices.enumerateDevices();
  const audioInputs = devices.filter((d) => d.kind === "audioinput");
  const defaultOpt = document.createElement("option");
  defaultOpt.value = "";
  defaultOpt.textContent = "Standart mikrofon";
  select.appendChild(defaultOpt);
  if (audioInputs.length === 0) {
    const noneOpt = document.createElement("option");
    noneOpt.value = "";
    noneOpt.textContent = "Mikrofon topilmadi";
    noneOpt.disabled = true;
    select.appendChild(noneOpt);
    return;
  }
  for (const device of audioInputs) {
    const opt = document.createElement("option");
    opt.value = device.deviceId;
    opt.textContent = device.label || `Mikrofon ${device.deviceId.slice(0, 8)}`;
    if (device.deviceId === currentDeviceId) opt.selected = true;
    select.appendChild(opt);
  }
  if (!currentDeviceId) {
    select.value = "";
  }
}
async function buildPermissionsSection(container) {
  container.appendChild(sectionHeader("Ruxsatlar"));
  async function permRow(label, constraint, permName) {
    const group = document.createElement("div");
    group.className = "field-group";
    const rowEl = document.createElement("div");
    rowEl.className = "perm-row";
    const labelEl = document.createElement("span");
    labelEl.className = "field-label";
    labelEl.textContent = label;
    const statusEl = document.createElement("span");
    statusEl.className = "perm-status";
    const grantBtn = document.createElement("button");
    grantBtn.type = "button";
    grantBtn.className = "btn btn--primary";
    grantBtn.textContent = `${label.toLowerCase()}ga ruxsat berish`;
    async function refresh() {
      let state = "prompt";
      try {
        const s = await navigator.permissions.query({ name: permName });
        state = s.state;
      } catch {
        state = "prompt";
      }
      if (state === "granted") {
        statusEl.textContent = "\u2713 Yoqilgan";
        statusEl.className = "perm-status perm-status--ok";
        grantBtn.style.display = "none";
      } else if (state === "denied") {
        statusEl.textContent = "Bloklangan \u2014 brauzer sozlamalarini tekshiring";
        statusEl.className = "perm-status perm-status--denied";
        grantBtn.style.display = "none";
      } else {
        statusEl.textContent = "Berilmagan";
        statusEl.className = "perm-status perm-status--unknown";
        grantBtn.style.display = "";
      }
    }
    grantBtn.addEventListener("click", async () => {
      grantBtn.disabled = true;
      try {
        const stream = await navigator.mediaDevices.getUserMedia(constraint);
        for (const t of stream.getTracks()) t.stop();
        statusEl.textContent = "\u2713 Yoqilgan";
        statusEl.className = "perm-status perm-status--ok";
        grantBtn.style.display = "none";
      } catch {
        statusEl.textContent = "Ruxsat berilmadi \u2014 brauzer sozlamalarini tekshiring";
        statusEl.className = "perm-status perm-status--denied";
        grantBtn.style.display = "none";
      } finally {
        grantBtn.disabled = false;
      }
    });
    rowEl.appendChild(labelEl);
    rowEl.appendChild(statusEl);
    group.appendChild(rowEl);
    group.appendChild(grantBtn);
    container.appendChild(group);
    await refresh();
  }
  await permRow("Mikrofon", { audio: true }, "microphone");
  await permRow("Kamera", { video: true }, "camera");
}
function buildAccountSection(settings, container) {
  container.appendChild(sectionHeader("Hisob"));
  const apiBaseUrlInput = document.createElement("input");
  apiBaseUrlInput.type = "url";
  apiBaseUrlInput.id = "apiBaseUrl";
  apiBaseUrlInput.className = "text-input";
  apiBaseUrlInput.value = settings.apiBaseUrl || DEFAULT_API_BASE_URL;
  apiBaseUrlInput.placeholder = "https://your-data365-instance.com";
  container.appendChild(fieldGroup("data365 server manzili", apiBaseUrlInput));
  const apiKeyWrapper = document.createElement("div");
  apiKeyWrapper.className = "input-with-button";
  const apiKeyInput = document.createElement("input");
  apiKeyInput.type = "password";
  apiKeyInput.id = "apiKey";
  apiKeyInput.className = "text-input";
  apiKeyInput.value = settings.apiKey || "";
  apiKeyInput.placeholder = "data365 API kalitini joylashtiring";
  const showHideBtn = document.createElement("button");
  showHideBtn.type = "button";
  showHideBtn.className = "btn btn--secondary btn--icon";
  showHideBtn.textContent = "Ko'rsatish";
  showHideBtn.addEventListener("click", () => {
    if (apiKeyInput.type === "password") {
      apiKeyInput.type = "text";
      showHideBtn.textContent = "Yashirish";
    } else {
      apiKeyInput.type = "password";
      showHideBtn.textContent = "Ko'rsatish";
    }
  });
  const saveConnectBtn = document.createElement("button");
  saveConnectBtn.type = "button";
  saveConnectBtn.className = "btn btn--primary";
  saveConnectBtn.textContent = "Saqlash va ulanish";
  saveConnectBtn.addEventListener("click", async () => {
    const key = apiKeyInput.value.trim();
    if (!key) {
      showToast("Avval kalitni joylashtiring");
      return;
    }
    saveConnectBtn.disabled = true;
    const baseUrl = apiBaseUrlInput.value.trim() || DEFAULT_API_BASE_URL;
    try {
      const res = await fetch(`${baseUrl}/api/extension/me`, {
        headers: { Authorization: `Bearer ${key}` }
      });
      if (res.ok) {
        await saveSettings({ apiKey: key, apiBaseUrl: baseUrl });
        showToast("Ulandi \u2713");
      } else {
        await saveSettings({ apiBaseUrl: baseUrl });
        showToast(
          res.status === 401 ? "Kalit qabul qilinmadi \u2014 kalitni tekshiring" : `Server xatosi (${res.status}) \u2014 kalitni tekshiring`
        );
      }
    } catch {
      await saveSettings({ apiBaseUrl: baseUrl });
      showToast("Serverga ulanib bo'lmadi \u2014 URL manzilini tekshiring");
    } finally {
      saveConnectBtn.disabled = false;
    }
  });
  apiKeyWrapper.appendChild(apiKeyInput);
  apiKeyWrapper.appendChild(showHideBtn);
  apiKeyWrapper.appendChild(saveConnectBtn);
  const apiKeyGroup = document.createElement("div");
  apiKeyGroup.className = "field-group";
  const apiKeyLabel = document.createElement("label");
  apiKeyLabel.className = "field-label";
  apiKeyLabel.htmlFor = "apiKey";
  apiKeyLabel.textContent = "API kaliti";
  apiKeyGroup.appendChild(apiKeyLabel);
  apiKeyGroup.appendChild(apiKeyWrapper);
  container.appendChild(apiKeyGroup);
  const connectionRow = document.createElement("div");
  connectionRow.className = "button-row";
  const testBtn = document.createElement("button");
  testBtn.type = "button";
  testBtn.className = "btn btn--primary";
  testBtn.textContent = "Ulanishni tekshirish";
  const connectionStatus = document.createElement("span");
  connectionStatus.className = "connection-status";
  testBtn.addEventListener("click", async () => {
    testBtn.disabled = true;
    connectionStatus.className = "connection-status connection-status--loading";
    connectionStatus.textContent = "Tekshirilmoqda\u2026";
    const baseUrl = apiBaseUrlInput.value.trim() || DEFAULT_API_BASE_URL;
    const key = apiKeyInput.value.trim();
    try {
      const res = await fetch(`${baseUrl}/api/extension/me`, {
        headers: key ? { Authorization: `Bearer ${key}` } : {}
      });
      if (res.ok) {
        connectionStatus.className = "connection-status connection-status--success";
        let label = "\u2713 Ulandi";
        try {
          const data = await res.json();
          const identity = typeof data.name === "string" && data.name ? data.name : typeof data.email === "string" && data.email ? data.email : null;
          if (identity) label = `\u2713 ${identity} sifatida ulandi`;
        } catch {
        }
        connectionStatus.textContent = label;
      } else {
        connectionStatus.className = "connection-status connection-status--error";
        connectionStatus.textContent = "\xD7 Ulanish amalga oshmadi";
      }
    } catch {
      connectionStatus.className = "connection-status connection-status--error";
      connectionStatus.textContent = "\xD7 Ulanish amalga oshmadi";
    } finally {
      testBtn.disabled = false;
    }
  });
  const signInBtn = document.createElement("button");
  signInBtn.type = "button";
  signInBtn.className = "btn btn--secondary";
  signInBtn.textContent = "data365 orqali kirish";
  signInBtn.addEventListener("click", () => {
    signInBtn.disabled = true;
    showToast("Kirish oynasi ochilmoqda\u2026");
    chrome.runtime.sendMessage({ type: "START_SIGNIN" }, (resp) => {
      signInBtn.disabled = false;
      if (chrome.runtime.lastError) {
        showToast("Kirishda xatolik \u2014 qayta urinib ko'ring");
        return;
      }
      const r = resp ?? {};
      if (r.ok) {
        showToast("Ulandi \u2713");
        location.reload();
      } else {
        showToast(r.error ? `Kirish amalga oshmadi: ${r.error}` : "Kirish amalga oshmadi \u2014 pastga kalitni joylashtiring");
      }
    });
  });
  connectionRow.appendChild(testBtn);
  connectionRow.appendChild(signInBtn);
  connectionRow.appendChild(connectionStatus);
  container.appendChild(connectionRow);
  return { apiBaseUrlInput, apiKeyInput };
}
async function buildRecordingSection(settings, container) {
  container.appendChild(divider());
  container.appendChild(sectionHeader("Yozuv"));
  const micSelect = document.createElement("select");
  micSelect.id = "micDeviceId";
  micSelect.className = "text-input";
  container.appendChild(fieldGroup("Mikrofon", micSelect));
  populateMicrophoneSelect(micSelect, settings.micDeviceId).catch(() => {
  });
  micSelect.addEventListener("change", async () => {
    await saveSettings({ micDeviceId: micSelect.value });
    showToast("Saqlandi");
  });
  const captureModeGroup = document.createElement("div");
  captureModeGroup.className = "field-group";
  const captureModeLabel = document.createElement("span");
  captureModeLabel.className = "field-label";
  captureModeLabel.textContent = "Ekranni yozish usuli";
  captureModeGroup.appendChild(captureModeLabel);
  const modes = [
    {
      value: "picker",
      label: "Tizim tanlagichi",
      description: "Har safar ekran, oyna yoki tabni tanlang (tavsiya etiladi)"
    },
    {
      value: "silent-tab",
      label: "Joriy tabni tezkor yozish",
      description: "Tanlash oynasini ko'rsatmasdan faol tabni yozadi (murakkab foydalanuvchilar uchun)"
    }
  ];
  for (const mode of modes) {
    const radioRow = document.createElement("label");
    radioRow.className = "radio-row";
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "captureMode";
    radio.value = mode.value;
    radio.checked = settings.captureMode === mode.value;
    const radioTextBlock = document.createElement("div");
    const radioLabel = document.createElement("span");
    radioLabel.className = "field-label";
    radioLabel.textContent = mode.label;
    const radioDesc = document.createElement("p");
    radioDesc.className = "field-description";
    radioDesc.textContent = mode.description;
    radioTextBlock.appendChild(radioLabel);
    radioTextBlock.appendChild(radioDesc);
    radioRow.appendChild(radio);
    radioRow.appendChild(radioTextBlock);
    captureModeGroup.appendChild(radioRow);
    radio.addEventListener("change", async () => {
      if (radio.checked) {
        await saveSettings({ captureMode: mode.value });
        showToast("Saqlandi");
      }
    });
  }
  container.appendChild(captureModeGroup);
}
function buildMeetSection(settings, container) {
  container.appendChild(divider());
  container.appendChild(sectionHeader("Google Meet"));
  const autoRecordToggleEl = createToggle(
    "autoRecordOnMeet",
    settings.autoRecordOnMeet
  );
  const autoRecordInput = autoRecordToggleEl.querySelector(
    "input"
  );
  const autoRecordRow = document.createElement("div");
  autoRecordRow.className = "toggle-row";
  const autoRecordTextBlock = document.createElement("div");
  const autoRecordLabel = document.createElement("span");
  autoRecordLabel.className = "field-label";
  autoRecordLabel.textContent = "Meetga qo'shilganda avtomatik yozish";
  autoRecordTextBlock.appendChild(autoRecordLabel);
  autoRecordRow.appendChild(autoRecordTextBlock);
  autoRecordRow.appendChild(autoRecordToggleEl);
  const autoRecordGroup = document.createElement("div");
  autoRecordGroup.className = "field-group";
  autoRecordGroup.appendChild(autoRecordRow);
  const warningBox = document.createElement("div");
  warningBox.className = "warning-box";
  warningBox.textContent = "Google Meet chaqiruviga qo'shilganingizda avtomatik yozish 5 soniyalik sanoq bilan boshlanadi. Ishtirokchilar yozib olinishga rozi bo'lganiga ishonch hosil qiling. data365 hech qachon bu sanoqni ko'rsatmasdan yozishni boshlamaydi. Sanoq davomida uni bekor qilishingiz mumkin.";
  warningBox.style.display = settings.autoRecordOnMeet ? "block" : "none";
  autoRecordGroup.appendChild(warningBox);
  container.appendChild(autoRecordGroup);
  const countdownSec = settings.autoRecordCountdownSec ?? 5;
  const countdownGroup = document.createElement("div");
  countdownGroup.className = "field-group";
  countdownGroup.style.display = settings.autoRecordOnMeet ? "block" : "none";
  const countdownLabel = document.createElement("label");
  countdownLabel.className = "field-label";
  countdownLabel.htmlFor = "countdownSlider";
  countdownLabel.textContent = "Sanoq davomiyligi";
  countdownGroup.appendChild(countdownLabel);
  const sliderRow = document.createElement("div");
  sliderRow.className = "slider-row";
  const slider = document.createElement("input");
  slider.type = "range";
  slider.id = "countdownSlider";
  slider.min = "3";
  slider.max = "10";
  slider.step = "1";
  slider.value = String(countdownSec);
  slider.className = "range-slider";
  const sliderValue = document.createElement("span");
  sliderValue.className = "slider-value";
  sliderValue.textContent = `${countdownSec} soniya`;
  slider.addEventListener("input", () => {
    sliderValue.textContent = `${slider.value} soniya`;
  });
  slider.addEventListener("change", async () => {
    await saveSettings({ autoRecordCountdownSec: Number(slider.value) });
    showToast("Saqlandi");
  });
  sliderRow.appendChild(slider);
  sliderRow.appendChild(sliderValue);
  countdownGroup.appendChild(sliderRow);
  container.appendChild(countdownGroup);
  autoRecordInput.addEventListener("change", async () => {
    const on = autoRecordInput.checked;
    warningBox.style.display = on ? "block" : "none";
    countdownGroup.style.display = on ? "block" : "none";
    await saveSettings({ autoRecordOnMeet: on });
    showToast("Saqlandi");
  });
  const soundToggleEl = createToggle("soundEnabled", settings.soundEnabled);
  const soundInput = soundToggleEl.querySelector("input");
  const soundRow = document.createElement("div");
  soundRow.className = "toggle-row";
  const soundTextBlock = document.createElement("div");
  const soundLabel = document.createElement("span");
  soundLabel.className = "field-label";
  soundLabel.textContent = "Bildirishnoma ovozlari";
  soundTextBlock.appendChild(soundLabel);
  soundRow.appendChild(soundTextBlock);
  soundRow.appendChild(soundToggleEl);
  const soundGroup = document.createElement("div");
  soundGroup.className = "field-group";
  soundGroup.appendChild(soundRow);
  container.appendChild(soundGroup);
  soundInput.addEventListener("change", async () => {
    await saveSettings({ soundEnabled: soundInput.checked });
    showToast("Saqlandi");
  });
}
function buildAboutSection(settings, container) {
  container.appendChild(divider());
  container.appendChild(sectionHeader("Haqida"));
  const version = document.createElement("p");
  version.className = "about-version";
  version.textContent = "data365 Recorder v0.1.0";
  container.appendChild(version);
  const links = document.createElement("div");
  links.className = "about-links";
  const baseUrl = settings.apiBaseUrl || DEFAULT_API_BASE_URL;
  const linkDefs = [
    { label: "Kengaytma sahifasi", href: `${baseUrl}/extension/install` },
    { label: "data365 boshqaruv paneli", href: `${baseUrl}/dashboard` },
    {
      label: "Muammo haqida xabar berish",
      href: "https://github.com/CapSoftware/Cap/issues"
    }
  ];
  for (const def of linkDefs) {
    const a = document.createElement("a");
    a.href = def.href;
    a.textContent = def.label;
    a.className = "about-link";
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    links.appendChild(a);
  }
  container.appendChild(links);
  const tagline = document.createElement("p");
  tagline.className = "about-tagline";
  tagline.textContent = "data365 \u2014 ko'rsatmalar uchun ekran yozish";
  container.appendChild(tagline);
}
async function init() {
  const root = document.getElementById("root");
  if (!root) return;
  const settings = await loadSettings();
  const container = document.createElement("div");
  container.className = "settings-container";
  await buildPermissionsSection(container);
  container.appendChild(divider());
  const { apiBaseUrlInput, apiKeyInput } = buildAccountSection(
    settings,
    container
  );
  await buildRecordingSection(settings, container);
  buildMeetSection(settings, container);
  buildAboutSection(settings, container);
  root.appendChild(container);
  function saveOnBlur(input, key) {
    input.addEventListener("blur", async () => {
      await saveSettings({ [key]: input.value.trim() });
      showToast("Saqlandi");
    });
  }
  saveOnBlur(apiBaseUrlInput, "apiBaseUrl");
  chrome.runtime.onMessage.addListener((message) => {
    if (typeof message === "object" && message !== null && message.type === "CAP_EXTENSION_TOKEN") {
      const msg = message;
      const token = typeof msg.token === "string" ? msg.token : "";
      const newBaseUrl = typeof msg.apiBaseUrl === "string" ? msg.apiBaseUrl : "";
      if (token) apiKeyInput.value = token;
      if (newBaseUrl) apiBaseUrlInput.value = newBaseUrl;
      saveSettings({
        apiKey: token,
        ...newBaseUrl ? { apiBaseUrl: newBaseUrl } : {}
      }).then(() => showToast("Muvaffaqiyatli kirildi!")).catch(() => {
      });
    }
  });
}
init().catch(console.error);
//# sourceMappingURL=options.js.map
