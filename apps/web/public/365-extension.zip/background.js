// src/background/keepalive.ts
var KEEPALIVE_ALARM = "cap-keepalive";
var KEEPALIVE_INTERVAL_MINUTES = 1;
function startKeepAlive() {
  chrome.alarms.create(KEEPALIVE_ALARM, {
    periodInMinutes: KEEPALIVE_INTERVAL_MINUTES
  });
}
function stopKeepAlive() {
  chrome.alarms.clear(KEEPALIVE_ALARM);
}
function isKeepAliveAlarm(alarmName) {
  return alarmName === KEEPALIVE_ALARM;
}

// src/shared/config.ts
var extensionEnv = globalThis.process?.env;
var fallbackApiBaseUrl = "https://data365.duckdns.org";
var DEFAULT_API_BASE_URL = [
  extensionEnv?.EXTENSION_API_BASE_URL,
  extensionEnv?.WEB_URL,
  extensionEnv?.NEXT_PUBLIC_WEB_URL,
  fallbackApiBaseUrl
].map((value) => value?.trim()).find((value) => Boolean(value)) ?? fallbackApiBaseUrl;

// src/background/state.ts
var STATE_KEY = "capExtState";
var SETTINGS_KEY = "capExtSettings";
var DEFAULT_SETTINGS = {
  apiBaseUrl: DEFAULT_API_BASE_URL,
  apiKey: "",
  autoRecordOnMeet: false,
  autoRecordCountdownSec: 5,
  micDeviceId: "",
  micEnabled: true,
  captureMode: "picker",
  soundEnabled: true,
  cameraOverlay: false,
  cameraDeviceId: ""
};
async function getState() {
  const result = await chrome.storage.local.get(STATE_KEY);
  return result[STATE_KEY] ?? { kind: "idle" };
}
async function setState(state) {
  await chrome.storage.local.set({ [STATE_KEY]: state });
  broadcastState(state);
}
function broadcastState(state) {
  const payload = { type: "STATE_CHANGED", state };
  chrome.runtime.sendMessage(payload).catch(() => {
  });
  chrome.tabs.query({ url: "https://meet.google.com/*" }).then((tabs) => {
    for (const tab of tabs) {
      if (tab.id != null) {
        chrome.tabs.sendMessage(tab.id, payload).catch(() => {
        });
      }
    }
  }).catch(() => {
  });
}
async function getSettings() {
  const result = await chrome.storage.local.get(SETTINGS_KEY);
  const stored = result[SETTINGS_KEY] ?? {};
  return { ...DEFAULT_SETTINGS, ...stored };
}
async function setSettings(settings) {
  const current = await getSettings();
  await chrome.storage.local.set({
    [SETTINGS_KEY]: { ...current, ...settings }
  });
}

// src/background/api.ts
async function handleResponse(res, label) {
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`[api] ${label} failed ${res.status}: ${body}`);
  }
  return res.json();
}
function createCapApi(baseUrl, apiKey) {
  const authHeader = { Authorization: `Bearer ${apiKey}` };
  return {
    async createVideo({ recordingMode, name, extensionContext, meetingId }) {
      const url = new URL(`${baseUrl}/api/desktop/video/create`);
      url.searchParams.set("recordingMode", recordingMode);
      if (name) url.searchParams.set("name", name);
      if (extensionContext)
        url.searchParams.set("extensionContext", extensionContext);
      if (meetingId) url.searchParams.set("meetingId", meetingId);
      const res = await fetch(url.toString(), {
        headers: authHeader
      });
      return handleResponse(res, "createVideo");
    },
    async initiateMultipart({ contentType, videoId, subpath }) {
      const body = { contentType, videoId };
      if (subpath) body.subpath = subpath;
      const res = await fetch(`${baseUrl}/api/upload/multipart/initiate`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      return handleResponse(
        res,
        "initiateMultipart"
      );
    },
    async presignPart({ uploadId, partNumber, videoId, subpath }) {
      const body = {
        uploadId,
        partNumber,
        videoId
      };
      if (subpath) body.subpath = subpath;
      const res = await fetch(`${baseUrl}/api/upload/multipart/presign-part`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      return handleResponse(res, "presignPart");
    },
    async completeMultipart({ uploadId, parts, videoId, subpath }) {
      const body = { uploadId, parts, videoId };
      if (subpath) body.subpath = subpath;
      const res = await fetch(`${baseUrl}/api/upload/multipart/complete`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      return handleResponse(
        res,
        "completeMultipart"
      );
    },
    async recordingComplete({ videoId }) {
      const res = await fetch(`${baseUrl}/api/upload/recording-complete/`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify({ videoId })
      });
      if (res.status === 400 || res.status === 409) {
        return;
      }
      await handleResponse(res, "recordingComplete");
    }
  };
}

// src/background/upload.ts
var MIN_PART_SIZE = 5 * 1024 * 1024;
var RETRY_QUEUE_KEY = "capExtRetryQueue";
var DEAD_LETTER_KEY = "capExtDeadLetterQueue";
var PART_MAX_ATTEMPTS = 30;
var FINALIZE_MAX_ATTEMPTS = 400;
var BACKOFF_SECONDS = [1, 4, 16, 64, 256];
var RETRY_ALARM_NAME = "cap-retry-queue";
var RETRY_ALARM_INTERVAL_MINUTES = 1;
function isRetryAlarm(name) {
  return name === RETRY_ALARM_NAME;
}
var inMemoryBuffer = new Uint8Array(0);
var PENDING_BUFFER_KEY_PREFIX = "pendingBuffer:";
var PENDING_BUFFER_PERSIST_INTERVAL_MS = 2e3;
var PENDING_BUFFER_PERSIST_GROWTH_BYTES = 1 * 1024 * 1024;
var lastPersistedForUploadId;
var lastPersistAt = 0;
var lastPersistedLength = 0;
function pendingBufferKey(uploadId) {
  return `${PENDING_BUFFER_KEY_PREFIX}${uploadId}`;
}
async function persistPendingBuffer(uploadId) {
  await chrome.storage.local.set({
    [pendingBufferKey(uploadId)]: bytesToBase64(inMemoryBuffer)
  });
  lastPersistedForUploadId = uploadId;
  lastPersistAt = Date.now();
  lastPersistedLength = inMemoryBuffer.length;
}
async function maybePersistPendingBuffer(uploadId) {
  const now = Date.now();
  const grew = inMemoryBuffer.length - lastPersistedLength;
  const isNewUpload = lastPersistedForUploadId !== uploadId;
  if (isNewUpload || now - lastPersistAt >= PENDING_BUFFER_PERSIST_INTERVAL_MS || grew >= PENDING_BUFFER_PERSIST_GROWTH_BYTES) {
    await persistPendingBuffer(uploadId);
  }
}
async function clearPendingBuffer(uploadId) {
  await chrome.storage.local.remove(pendingBufferKey(uploadId));
  if (lastPersistedForUploadId === uploadId) {
    lastPersistedForUploadId = void 0;
    lastPersistAt = 0;
    lastPersistedLength = 0;
  }
}
async function restorePendingBufferIfNeeded(uploadId) {
  if (inMemoryBuffer.length > 0) return;
  const result = await chrome.storage.local.get(pendingBufferKey(uploadId));
  const stored = result[pendingBufferKey(uploadId)];
  if (!stored) return;
  inMemoryBuffer = base64ToBytes(stored);
  lastPersistedForUploadId = uploadId;
  lastPersistAt = Date.now();
  lastPersistedLength = inMemoryBuffer.length;
}
function bytesToBase64(bytes) {
  let binary = "";
  const chunkSize = 32768;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}
function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
function getPartRetryPayload(item) {
  const { partNumber, videoId, uploadId, partDataBase64 } = item.payload;
  if (typeof partNumber !== "number" || typeof videoId !== "string" || typeof uploadId !== "string" || typeof partDataBase64 !== "string") {
    return void 0;
  }
  return { partNumber, videoId, uploadId, partDataBase64 };
}
function upsertCompletedPart(parts, completedPart) {
  const withoutPart = parts.filter(
    (part) => part.PartNumber !== completedPart.PartNumber
  );
  return [...withoutPart, completedPart].sort(
    (a, b) => a.PartNumber - b.PartNumber
  );
}
function appendToBuffer(chunk) {
  const merged = new Uint8Array(inMemoryBuffer.length + chunk.length);
  merged.set(inMemoryBuffer, 0);
  merged.set(chunk, inMemoryBuffer.length);
  inMemoryBuffer = merged;
}
function drainBuffer() {
  const drained = inMemoryBuffer;
  inMemoryBuffer = new Uint8Array(0);
  return drained;
}
function takeFixedSizeParts(buffer, partSize) {
  const parts = [];
  let offset = 0;
  while (buffer.length - offset >= partSize) {
    parts.push(buffer.slice(offset, offset + partSize));
    offset += partSize;
  }
  return { parts, remainder: buffer.slice(offset) };
}
function computeNextPartNumberForUploading(parts, queue, videoId, uploadId) {
  let maxPartNumber = 0;
  for (const part of parts) {
    if (part.PartNumber > maxPartNumber) maxPartNumber = part.PartNumber;
  }
  for (const item of queue) {
    if (item.kind !== "part") continue;
    const payload = getPartRetryPayload(item);
    if (!payload) continue;
    if (payload.videoId !== videoId || payload.uploadId !== uploadId) continue;
    if (payload.partNumber > maxPartNumber) maxPartNumber = payload.partNumber;
  }
  return maxPartNumber + 1;
}
async function getRetryQueue() {
  const result = await chrome.storage.local.get(RETRY_QUEUE_KEY);
  return result[RETRY_QUEUE_KEY] ?? [];
}
async function setRetryQueue(queue) {
  await chrome.storage.local.set({ [RETRY_QUEUE_KEY]: queue });
  if (queue.length > 0) {
    chrome.alarms.create(RETRY_ALARM_NAME, {
      periodInMinutes: RETRY_ALARM_INTERVAL_MINUTES
    });
  } else {
    chrome.alarms.clear(RETRY_ALARM_NAME);
  }
}
async function addToRetryQueue(item) {
  const queue = await getRetryQueue();
  queue.push({ ...item, attempts: 0, nextRetryAt: Date.now() + 1e3 });
  await setRetryQueue(queue);
}
async function moveToDeadLetter(item) {
  const result = await chrome.storage.local.get(DEAD_LETTER_KEY);
  const dead = result[DEAD_LETTER_KEY] ?? [];
  dead.push(item);
  await chrome.storage.local.set({ [DEAD_LETTER_KEY]: dead });
  const deadVideoId = item.payload?.videoId;
  if (deadVideoId) {
    const liveState = await getState();
    const liveVideoId = liveState.kind === "error" ? liveState.previousVideoId : "videoId" in liveState ? liveState.videoId : void 0;
    if (liveVideoId === deadVideoId && (liveState.kind === "uploading" || liveState.kind === "finishing")) {
      await setState({
        kind: "error",
        reason: "Upload failed and could not be recovered. Please re-record \u2014 you can start a new recording now.",
        recoverable: true,
        previousVideoId: deadVideoId
      });
    }
  }
  chrome.notifications.create({
    type: "basic",
    iconUrl: "/icons/icon-48.png",
    title: "data365 upload failed",
    message: "Upload failed and could not be recovered. This recording is lost \u2014 please re-record."
  });
}
async function requireSettings() {
  const settings = await getSettings();
  if (!settings.apiKey) {
    throw new Error("[upload] apiKey is not configured in extension settings");
  }
  return settings;
}
async function uploadPart(partData, partNumber, videoId, uploadId, settings) {
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  const { presignedUrl } = await api.presignPart({
    uploadId,
    partNumber,
    videoId,
    subpath: "result.mp4"
  });
  const putRes = await fetch(presignedUrl, {
    method: "PUT",
    headers: { "Content-Type": "application/octet-stream" },
    body: partData
  });
  if (!putRes.ok) {
    const text = await putRes.text().catch(() => "");
    throw new Error(
      `[upload] PUT part ${partNumber} failed ${putRes.status}: ${text}`
    );
  }
  const etag = putRes.headers.get("ETag");
  return {
    ETag: etag ? etag.replace(/"/g, "") : "RESOLVE_SERVER_SIDE",
    PartNumber: partNumber
  };
}
async function recordCompletedPart(videoId, uploadId, completedPart, partSize) {
  const state = await getState();
  if (state.kind !== "recording" && state.kind !== "uploading" || state.videoId !== videoId || state.uploadId !== uploadId) {
    return;
  }
  const alreadyRecorded = state.parts.some(
    (part) => part.PartNumber === completedPart.PartNumber
  );
  await setState({
    ...state,
    parts: upsertCompletedPart(state.parts, completedPart),
    uploadedBytes: alreadyRecorded ? state.uploadedBytes : state.uploadedBytes + partSize
  });
}
function enqueuePartRetryPayload(partData, partNumber, videoId, uploadId) {
  return {
    kind: "part",
    payload: {
      partNumber,
      videoId,
      uploadId,
      partDataBase64: bytesToBase64(partData)
    }
  };
}
function scheduleRetry(item, now) {
  const nextAttempts = item.attempts + 1;
  const isFinalization = item.kind === "complete" || item.kind === "recording-complete";
  const maxAttempts = isFinalization ? FINALIZE_MAX_ATTEMPTS : PART_MAX_ATTEMPTS;
  if (nextAttempts >= maxAttempts) return void 0;
  const delaySec = BACKOFF_SECONDS[nextAttempts - 1] ?? 256;
  return {
    ...item,
    attempts: nextAttempts,
    nextRetryAt: now + delaySec * 1e3
  };
}
async function retryQueuedPartsForUpload(videoId, uploadId, parts, settings) {
  const queue = await getRetryQueue();
  const remaining = [];
  const now = Date.now();
  let nextParts = parts;
  let failed = false;
  for (const item of queue) {
    const payload = item.kind === "part" ? getPartRetryPayload(item) : void 0;
    if (item.kind !== "part") {
      remaining.push(item);
      continue;
    }
    if (!payload) {
      if (item.payload.videoId === videoId && item.payload.uploadId === uploadId) {
        failed = true;
        await moveToDeadLetter(item);
      } else {
        remaining.push(item);
      }
      continue;
    }
    if (payload.videoId !== videoId || payload.uploadId !== uploadId) {
      remaining.push(item);
      continue;
    }
    try {
      const partData = base64ToBytes(payload.partDataBase64);
      const completedPart = await uploadPart(
        partData,
        payload.partNumber,
        payload.videoId,
        payload.uploadId,
        settings
      );
      nextParts = upsertCompletedPart(nextParts, completedPart);
      await recordCompletedPart(
        payload.videoId,
        payload.uploadId,
        completedPart,
        partData.length
      );
    } catch (err) {
      console.error("[upload] Queued part retry failed:", err);
      failed = true;
      const rescheduled = scheduleRetry(item, now);
      if (rescheduled) {
        remaining.push(rescheduled);
      } else {
        await moveToDeadLetter({ ...item, attempts: item.attempts + 1 });
      }
    }
  }
  const remainingPartsQueued = remaining.some(
    (item) => item.kind === "part" && item.payload.videoId === videoId && item.payload.uploadId === uploadId
  );
  await setRetryQueue(remaining);
  return { parts: nextParts, failed, remainingPartsQueued };
}
async function initializeUpload(mode, meetingId) {
  const settings = await requireSettings();
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  const now = /* @__PURE__ */ new Date();
  const dateStr = now.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
  const name = mode === "meeting" && meetingId ? `data365 Meeting \u2014 ${meetingId}` : `data365 Recording \u2014 ${dateStr}`;
  const { id: videoId } = await api.createVideo({
    recordingMode: "extensionWeb",
    name,
    extensionContext: mode,
    meetingId
  });
  const { uploadId } = await api.initiateMultipart({
    contentType: "video/webm",
    videoId,
    subpath: "result.mp4"
  });
  inMemoryBuffer = new Uint8Array(0);
  lastPersistedForUploadId = void 0;
  lastPersistAt = 0;
  lastPersistedLength = 0;
  return { videoId, uploadId };
}
async function abortUpload(uploadId) {
  await clearPendingBuffer(uploadId);
}
async function handleChunk(chunk, _index, _mime) {
  const state = await getState();
  if (state.kind !== "recording") return;
  await restorePendingBufferIfNeeded(state.uploadId);
  const data = new Uint8Array(chunk);
  appendToBuffer(data);
  const newTotalBytes = state.totalBytes + data.length;
  const { parts: fullParts, remainder } = takeFixedSizeParts(
    inMemoryBuffer,
    MIN_PART_SIZE
  );
  if (fullParts.length === 0) {
    await maybePersistPendingBuffer(state.uploadId);
    await setState({ ...state, totalBytes: newTotalBytes });
    return;
  }
  inMemoryBuffer = remainder;
  try {
    await persistPendingBuffer(state.uploadId);
  } catch (err) {
    console.error(
      "[upload] Failed to persist pending buffer \u2014 continuing so the already-sliced parts are still uploaded:",
      err
    );
  }
  const settings = await requireSettings();
  let partNumber = state.nextPartNumber;
  for (const partData of fullParts) {
    try {
      const completedPart = await uploadPart(
        partData,
        partNumber,
        state.videoId,
        state.uploadId,
        settings
      );
      const freshState = await getState();
      if (freshState.kind !== "recording" || freshState.videoId !== state.videoId || freshState.uploadId !== state.uploadId) {
        return;
      }
      await setState({
        ...freshState,
        parts: [...freshState.parts, completedPart],
        nextPartNumber: Math.max(freshState.nextPartNumber, partNumber + 1),
        totalBytes: Math.max(freshState.totalBytes, newTotalBytes),
        uploadedBytes: freshState.uploadedBytes + partData.length
      });
    } catch (err) {
      console.error("[upload] Part upload failed:", err);
      await addToRetryQueue(
        enqueuePartRetryPayload(
          partData,
          partNumber,
          state.videoId,
          state.uploadId
        )
      );
      const freshState = await getState();
      if (freshState.kind === "recording" && freshState.videoId === state.videoId && freshState.uploadId === state.uploadId) {
        await setState({
          ...freshState,
          nextPartNumber: Math.max(freshState.nextPartNumber, partNumber + 1),
          totalBytes: Math.max(freshState.totalBytes, newTotalBytes)
        });
      }
    }
    partNumber += 1;
  }
}
async function finalizeUpload() {
  const state = await getState();
  if (state.kind !== "recording" && state.kind !== "uploading") return;
  const settings = await requireSettings();
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  let parts = [...state.parts];
  let nextPartNumber = state.kind === "recording" ? state.nextPartNumber : computeNextPartNumberForUploading(
    state.parts,
    await getRetryQueue(),
    state.videoId,
    state.uploadId
  );
  const totalBytes = state.totalBytes;
  const uploadedBytes = "uploadedBytes" in state ? state.uploadedBytes : 0;
  const { videoId, uploadId } = state;
  await restorePendingBufferIfNeeded(uploadId);
  const durableBytes = uploadedBytes + inMemoryBuffer.length;
  const MIN_VIABLE_BYTES = 10 * 1024;
  if (durableBytes < MIN_VIABLE_BYTES) {
    console.error(
      `[upload] Recording too small (${durableBytes} durable bytes) \u2014 refusing to publish a broken video.`
    );
    await setState({
      kind: "error",
      reason: "Recording was too short \u2014 no video was captured. Please record for at least a couple of seconds and try again.",
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  if (state.kind === "recording") {
    await setState({
      kind: "uploading",
      videoId,
      uploadId,
      parts,
      totalBytes,
      uploadedBytes
    });
  }
  const remaining = drainBuffer();
  await clearPendingBuffer(uploadId);
  if (remaining.length > 0) {
    try {
      const completedPart = await uploadPart(
        remaining,
        nextPartNumber,
        videoId,
        uploadId,
        settings
      );
      parts = [...parts, completedPart];
      nextPartNumber += 1;
      await recordCompletedPart(
        videoId,
        uploadId,
        completedPart,
        remaining.length
      );
    } catch (err) {
      console.error("[upload] Final part upload failed:", err);
      await addToRetryQueue(
        enqueuePartRetryPayload(remaining, nextPartNumber, videoId, uploadId)
      );
    }
  }
  const queuedPartsResult = await retryQueuedPartsForUpload(
    videoId,
    uploadId,
    parts,
    settings
  );
  parts = queuedPartsResult.parts;
  if (queuedPartsResult.failed) {
    if (queuedPartsResult.remainingPartsQueued) {
      await addToRetryQueue({
        kind: "complete",
        payload: { uploadId, videoId }
      });
      return;
    }
    await setState({
      kind: "error",
      reason: "Upload part retry failed. Check network and try again.",
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  if (parts.length === 0) {
    const bufferLen = remaining.length;
    console.error(
      `[upload] No parts uploaded \u2014 cannot complete multipart. totalBytes=${totalBytes}, remainingBuffer=${bufferLen}`
    );
    await setState({
      kind: "error",
      reason: totalBytes === 0 ? "No recording data was captured. Check screen-capture permissions and try again." : `Upload failed \u2014 ${totalBytes} bytes captured but no parts uploaded. Check network or try again.`,
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  await setState({ kind: "finishing", videoId, uploadId, parts });
  try {
    const apiParts = parts.map((p) => ({
      partNumber: p.PartNumber,
      etag: p.ETag,
      size: 0
    }));
    await api.completeMultipart({
      uploadId,
      parts: apiParts,
      videoId,
      subpath: "result.mp4"
    });
  } catch (err) {
    console.error("[upload] completeMultipart failed:", err);
    await addToRetryQueue({
      kind: "complete",
      payload: {
        uploadId,
        videoId,
        parts: parts.map((p) => ({
          partNumber: p.PartNumber,
          etag: p.ETag,
          size: 0
        }))
      }
    });
    await setState({
      kind: "error",
      reason: `Upload finalization failed: ${err instanceof Error ? err.message : String(err)}`,
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  try {
    await api.recordingComplete({ videoId });
  } catch (err) {
    console.error("[upload] recordingComplete failed:", err);
    await addToRetryQueue({
      kind: "recording-complete",
      payload: { videoId }
    });
  }
  const shareUrl = `${settings.apiBaseUrl}/s/${videoId}`;
  await setState({ kind: "complete", videoId, shareUrl });
}
async function resumeInterruptedFinishing(videoId, uploadId, parts) {
  if (!uploadId || !parts || parts.length === 0) return false;
  await addToRetryQueue({
    kind: "complete",
    payload: {
      uploadId,
      videoId,
      parts: parts.map((p) => ({
        partNumber: p.PartNumber,
        etag: p.ETag,
        size: 0
      }))
    }
  });
  return true;
}
async function deadLetterHasPartForUpload(videoId, uploadId) {
  const result = await chrome.storage.local.get(DEAD_LETTER_KEY);
  const dead = result[DEAD_LETTER_KEY] ?? [];
  return dead.some(
    (d) => d.kind === "part" && d.payload.videoId === videoId && d.payload.uploadId === uploadId
  );
}
async function retryPendingUploads() {
  const queue = await getRetryQueue();
  if (queue.length === 0) return;
  const settings = await getSettings();
  if (!settings.apiKey) return;
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  const now = Date.now();
  const remaining = [];
  for (const item of queue) {
    if (item.nextRetryAt > now) {
      remaining.push(item);
      continue;
    }
    if (item.kind === "complete") {
      const { uploadId, videoId } = item.payload;
      const siblingPartsQueued = queue.some(
        (other) => other !== item && other.kind === "part" && other.payload.videoId === videoId && other.payload.uploadId === uploadId
      );
      if (siblingPartsQueued) {
        remaining.push(item);
        continue;
      }
      if (await deadLetterHasPartForUpload(videoId, uploadId)) {
        continue;
      }
    }
    try {
      if (item.kind === "part") {
        const payload = getPartRetryPayload(item);
        if (!payload) {
          await moveToDeadLetter(item);
          continue;
        }
        const partData = base64ToBytes(payload.partDataBase64);
        const completedPart = await uploadPart(
          partData,
          payload.partNumber,
          payload.videoId,
          payload.uploadId,
          settings
        );
        await recordCompletedPart(
          payload.videoId,
          payload.uploadId,
          completedPart,
          partData.length
        );
      } else if (item.kind === "complete") {
        const {
          uploadId,
          videoId,
          parts: snapshotParts
        } = item.payload;
        let parts = snapshotParts;
        if (!parts) {
          const liveState2 = await getState();
          parts = liveState2.kind === "uploading" && liveState2.videoId === videoId && liveState2.uploadId === uploadId ? liveState2.parts.map((p) => ({
            partNumber: p.PartNumber,
            etag: p.ETag,
            size: 0
          })) : [];
        }
        await api.completeMultipart({
          uploadId,
          parts,
          videoId,
          subpath: "result.mp4"
        });
        try {
          await api.recordingComplete({ videoId });
        } catch (recErr) {
          console.error(
            "[upload] recordingComplete failed after drained complete:",
            recErr
          );
          remaining.push({
            kind: "recording-complete",
            payload: { videoId },
            attempts: 0,
            nextRetryAt: Date.now() + 1e3
          });
        }
        const liveState = await getState();
        const liveVideoId = liveState.kind === "error" ? liveState.previousVideoId : "videoId" in liveState ? liveState.videoId : void 0;
        const stillOurs = liveVideoId === videoId && (liveState.kind === "uploading" || liveState.kind === "finishing" || liveState.kind === "error");
        if (stillOurs) {
          await setState({
            kind: "complete",
            videoId,
            shareUrl: `${settings.apiBaseUrl}/s/${videoId}`
          });
        }
      } else if (item.kind === "recording-complete") {
        const { videoId } = item.payload;
        await api.recordingComplete({ videoId });
      }
    } catch (err) {
      console.error(`[upload] Retry failed for ${item.kind}:`, err);
      const rescheduled = scheduleRetry(item, now);
      if (!rescheduled) {
        await moveToDeadLetter({ ...item, attempts: item.attempts + 1 });
      } else {
        remaining.push(rescheduled);
      }
    }
  }
  await setRetryQueue(remaining);
}

// src/background/sw.ts
function getTabMediaStreamId(targetTabId, consumerTabId) {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabCapture.getMediaStreamId(
        consumerTabId !== void 0 ? { targetTabId, consumerTabId } : { targetTabId },
        (streamId) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (!streamId) {
            reject(new Error("tabCapture returned no stream id"));
          } else {
            resolve(streamId);
          }
        }
      );
    } catch (err) {
      reject(err instanceof Error ? err : new Error(String(err)));
    }
  });
}
async function openInstructionRecorder() {
  const url = chrome.runtime.getURL("recorder.html");
  const existing = await chrome.tabs.query({ url });
  if (existing.length > 0 && existing[0].id != null) {
    await chrome.tabs.update(existing[0].id, { active: true });
    if (existing[0].windowId != null) {
      await chrome.windows.update(existing[0].windowId, { focused: true });
    }
    return existing[0].id;
  }
  const tab = await chrome.tabs.create({ url, active: true });
  return tab.id;
}
async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (existingContexts.length > 0) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Recording screen/tab media"
  });
}
async function closeOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (existingContexts.length > 0) {
    await chrome.offscreen.closeDocument();
  }
}
function sendToOffscreen(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
async function sendControlWithRetry(send, label, attempts = 4, delayMs = 150) {
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      await send();
      return true;
    } catch (err) {
      if (attempt === attempts) {
        console.warn(
          `[sw] control send failed after ${attempts} attempts: ${label}`,
          err
        );
        return false;
      }
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  return false;
}
function updateBadge(state) {
  switch (state.kind) {
    case "recording":
      chrome.action.setBadgeText({ text: "REC" });
      chrome.action.setBadgeBackgroundColor({ color: "#e53e3e" });
      break;
    case "uploading":
    case "finishing":
      chrome.action.setBadgeText({ text: "\u2191" });
      chrome.action.setBadgeBackgroundColor({ color: "#3182ce" });
      break;
    case "complete":
      chrome.action.setBadgeText({ text: "\u2713" });
      chrome.action.setBadgeBackgroundColor({ color: "#38a169" });
      break;
    case "error":
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#dd6b20" });
      break;
    default:
      chrome.action.setBadgeText({ text: "" });
      break;
  }
}
var intentionalStop = false;
var tabAudioDegradedNotified = false;
function notifyTabAudioDegraded(cause) {
  if (tabAudioDegradedNotified) return;
  tabAudioDegradedNotified = true;
  const messages = {
    muted: "The Meet tab was muted. Recording continues (screen+mic); client audio is not being captured until it's unmuted.",
    suspended: "Client audio briefly dropped mid-recording. Recording continues; attempting to recover.",
    ended: "The Meet tab was closed or navigated away. Recording continues (screen+mic only) \u2014 client audio can't be reconnected."
  };
  chrome.notifications.create("tab-audio-degraded", {
    type: "basic",
    iconUrl: "icons/icon-128.png",
    title: "Client audio degraded",
    message: messages[cause]
  });
  chrome.action.setBadgeText({ text: "!" });
  chrome.action.setBadgeBackgroundColor({ color: "#dd6b20" });
}
async function notifyTabAudioRecovered() {
  tabAudioDegradedNotified = false;
  chrome.notifications.clear("tab-audio-degraded");
  const st = await getState();
  updateBadge(st);
}
async function handleSourceTabLost(tabId) {
  const state = await getState();
  if (state.kind !== "recording" || !state.meetingRequired || state.sourceTabId !== tabId) {
    return;
  }
  if (intentionalStop) return;
  if (state.recorderTabId !== void 0) {
    await sendControlWithRetry(
      () => chrome.tabs.sendMessage(state.recorderTabId, {
        type: "TAB_AUDIO_LOST_REMOTE"
      }),
      "TAB_AUDIO_LOST_REMOTE\u2192tab"
    );
  }
  notifyTabAudioDegraded("ended");
}
var MEET_ENDED_PROMPT_ID = "meet-ended-stop-prompt";
function promptStopOnMeetEnded() {
  chrome.notifications.create(MEET_ENDED_PROMPT_ID, {
    type: "basic",
    iconUrl: "icons/icon-128.png",
    title: "Yig'ilish tugadi",
    message: "Google Meet qo'ng'irog'i tugadi. Yozuvni to'xtatasizmi, yoki ekran yozuvini davom ettirasizmi?",
    buttons: [{ title: "To'xtatish va saqlash" }, { title: "Davom ettirish" }],
    requireInteraction: true
  });
}
async function stopInstructionDeliberate() {
  const st = await getState();
  if (st.kind !== "recording" || st.mode !== "instruction") return;
  intentionalStop = true;
  if (st.recorderTabId !== void 0) {
    await sendControlWithRetry(
      () => chrome.tabs.sendMessage(st.recorderTabId, { type: "STOP_CAPTURE" }),
      "STOP_CAPTURE\u2192tab"
    );
  }
}
function isInProgress(state) {
  return state.kind === "recording" || state.kind === "uploading" || state.kind === "finishing";
}
function isMessageBase(v) {
  return typeof v === "object" && v !== null && "type" in v && typeof v.type === "string";
}
function getString(obj, key) {
  const v = obj[key];
  return typeof v === "string" ? v : void 0;
}
function originOf(url) {
  if (!url) return null;
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}
function isTrustedTokenSender(senderUrl, configuredApiBaseUrl) {
  const sender = originOf(senderUrl);
  if (!sender) return false;
  const allowed = /* @__PURE__ */ new Set();
  const configured = originOf(configuredApiBaseUrl);
  if (configured) allowed.add(configured);
  const defaultOrigin = originOf(DEFAULT_API_BASE_URL);
  if (defaultOrigin) allowed.add(defaultOrigin);
  allowed.add("http://localhost:3000");
  allowed.add("http://localhost:3001");
  return allowed.has(sender);
}
function getNumber(obj, key) {
  const v = obj[key];
  return typeof v === "number" ? v : void 0;
}
function _getBoolean(obj, key) {
  const v = obj[key];
  return typeof v === "boolean" ? v : void 0;
}
var MIN_MEET_RECORDING_MS_BEFORE_AUTO_STOP = 1e4;
function isMeetUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.hostname === "meet.google.com" && /^\/[a-z]+-[a-z]+-[a-z]+/.test(parsed.pathname);
  } catch {
    return false;
  }
}
async function resolveMeetSenderTabId(sender) {
  if (sender.tab?.id !== void 0 && isMeetUrl(sender.tab.url)) {
    return sender.tab.id;
  }
  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true,
    url: "https://meet.google.com/*"
  });
  const tab = tabs.find((t) => t.id !== void 0 && isMeetUrl(t.url));
  return tab?.id;
}
var recorderQueue = Promise.resolve();
function enqueueRecorder(fn) {
  const run = recorderQueue.then(fn, fn);
  recorderQueue = run.then(
    () => void 0,
    () => void 0
  );
  return run;
}
async function finalizeRecording() {
  const state = await getState();
  if (state.kind !== "recording") return;
  const videoId = state.videoId;
  const uploadId = state.uploadId;
  const parts = state.parts;
  const totalBytes = state.totalBytes;
  const uploadedBytes = state.uploadedBytes;
  const nextState = {
    kind: "uploading",
    videoId,
    uploadId,
    parts,
    totalBytes,
    uploadedBytes
  };
  await setState(nextState);
  stopKeepAlive();
  updateBadge(nextState);
  await closeOffscreenDocument().catch(() => {
  });
  await finalizeUpload();
}
async function handleMessage(message, _sender) {
  if (!isMessageBase(message)) return { ok: false, error: "invalid message" };
  const msg = message;
  const type = msg.type;
  switch (type) {
    // ── Popup: start instruction recording ────────────────────────────
    // Full-screen instruction capture happens in a dedicated VISIBLE tab
    // (recorder.html) where getDisplayMedia() has a real user gesture. The
    // SW only opens that tab; the page owns the MediaStream and streams
    // chunks back via the RECORDER_* protocol. We deliberately do NOT enter
    // "arming" here — the actual gesture/picker lives in the recorder tab,
    // so state advances to "recording" only when that page sends
    // RECORDER_STARTED.
    case "START_INSTRUCTION": {
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        return { ok: false, error: "not signed in" };
      }
      const sourceTabId = getNumber(msg, "sourceTabId");
      const meetingRequired = _getBoolean(msg, "meeting") === true;
      await setState({
        kind: "arming",
        mode: "instruction",
        sourceTabId,
        meetingRequired
      });
      let recorderTabId;
      try {
        recorderTabId = await openInstructionRecorder();
      } catch (err) {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
        return {
          ok: false,
          error: `Couldn't open the recorder: ${err instanceof Error ? err.message : String(err)}`
        };
      }
      await setState({
        kind: "arming",
        mode: "instruction",
        recorderTabId,
        sourceTabId,
        meetingRequired
      });
      return { ok: true };
    }
    // ── Popup: start meeting recording (Google Meet → tab capture) ────
    case "START_MEET": {
      const meetingId = getString(msg, "meetingId");
      const tabId = getNumber(msg, "tabId");
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      if (tabId === void 0) {
        return { ok: false, error: "No Meet tab to record" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        return { ok: false, error: "not signed in" };
      }
      await setState({ kind: "arming", mode: "meeting", meetingId, tabId });
      let meetStreamId;
      try {
        meetStreamId = await getTabMediaStreamId(tabId);
      } catch (err) {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
        return {
          ok: false,
          error: `Couldn't capture the meeting tab: ${err instanceof Error ? err.message : String(err)}`
        };
      }
      await ensureOffscreenDocument();
      await sendToOffscreen({
        type: "START_CAPTURE",
        streamId: meetStreamId,
        meetingId,
        tabId,
        micEnabled: settings.micEnabled,
        ...settings.micEnabled ? { micDeviceId: settings.micDeviceId } : {}
      });
      return { ok: true };
    }
    // ── Popup: stop ───────────────────────────────────────────────────
    case "STOP": {
      intentionalStop = true;
      const stopState = await getState();
      const stopTabId = stopState.kind === "recording" && stopState.mode === "instruction" ? stopState.recorderTabId : stopState.kind === "arming" && stopState.mode === "instruction" ? stopState.recorderTabId : void 0;
      const contentStopTabId = stopState.kind === "recording" && stopState.contentRecorderTabId !== void 0 ? stopState.contentRecorderTabId : stopState.kind === "arming" && stopState.contentRecorderTabId !== void 0 ? stopState.contentRecorderTabId : void 0;
      let stopDelivered;
      if (stopTabId !== void 0) {
        stopDelivered = await sendControlWithRetry(
          () => chrome.tabs.sendMessage(stopTabId, { type: "STOP_CAPTURE" }),
          "STOP_CAPTURE\u2192tab"
        );
      } else if (contentStopTabId !== void 0) {
        stopDelivered = await sendControlWithRetry(
          () => chrome.tabs.sendMessage(contentStopTabId, { type: "STOP_CAPTURE" }),
          "STOP_CAPTURE\u2192tab"
        );
      } else {
        stopDelivered = await sendControlWithRetry(
          () => sendToOffscreen({ type: "STOP_CAPTURE" }),
          "STOP_CAPTURE\u2192offscreen"
        );
      }
      if (!stopDelivered) {
        await enqueueRecorder(() => finalizeRecording());
      }
      return { ok: true };
    }
    // ── Popup: pause ──────────────────────────────────────────────────
    case "PAUSE": {
      const pauseState = await getState();
      const pauseTabId = pauseState.kind === "recording" && pauseState.mode === "instruction" ? pauseState.recorderTabId : void 0;
      if (pauseTabId !== void 0) {
        await sendControlWithRetry(
          () => chrome.tabs.sendMessage(pauseTabId, { type: "PAUSE_CAPTURE" }),
          "PAUSE_CAPTURE\u2192tab"
        );
      } else if (pauseState.kind === "recording" && pauseState.contentRecorderTabId !== void 0) {
        await sendControlWithRetry(
          () => chrome.tabs.sendMessage(pauseState.contentRecorderTabId, {
            type: "PAUSE_CAPTURE"
          }),
          "PAUSE_CAPTURE\u2192tab"
        );
      } else {
        await sendControlWithRetry(
          () => sendToOffscreen({ type: "PAUSE_CAPTURE" }),
          "PAUSE_CAPTURE\u2192offscreen"
        );
      }
      if (pauseState.kind === "recording") {
        await enqueueRecorder(async () => {
          const fresh = await getState();
          if (fresh.kind !== "recording") return;
          const nextState = { ...fresh, paused: true, pausedAt: Date.now() };
          await setState(nextState);
          updateBadge(nextState);
        });
      }
      return { ok: true };
    }
    // ── Popup: resume ─────────────────────────────────────────────────
    case "RESUME": {
      const resumeState = await getState();
      const resumeTabId = resumeState.kind === "recording" && resumeState.mode === "instruction" ? resumeState.recorderTabId : void 0;
      if (resumeTabId !== void 0) {
        await sendControlWithRetry(
          () => chrome.tabs.sendMessage(resumeTabId, { type: "RESUME_CAPTURE" }),
          "RESUME_CAPTURE\u2192tab"
        );
      } else if (resumeState.kind === "recording" && resumeState.contentRecorderTabId !== void 0) {
        await sendControlWithRetry(
          () => chrome.tabs.sendMessage(resumeState.contentRecorderTabId, {
            type: "RESUME_CAPTURE"
          }),
          "RESUME_CAPTURE\u2192tab"
        );
      } else {
        await sendControlWithRetry(
          () => sendToOffscreen({ type: "RESUME_CAPTURE" }),
          "RESUME_CAPTURE\u2192offscreen"
        );
      }
      if (resumeState.kind === "recording") {
        await enqueueRecorder(async () => {
          const fresh = await getState();
          if (fresh.kind !== "recording") return;
          const nextState = {
            ...fresh,
            paused: false,
            pausedAt: void 0,
            pausedAccumMs: (fresh.pausedAccumMs ?? 0) + (fresh.pausedAt ? Date.now() - fresh.pausedAt : 0)
          };
          await setState(nextState);
          updateBadge(nextState);
        });
      }
      return { ok: true };
    }
    // ── Recorder tab: instruction capture aborted before it began ─────
    // The visible recorder tab cancelled the screen picker or was closed
    // before recording started. Release the "arming" lock — but ONLY if we
    // are still arming an instruction, so an active recording (meeting or a
    // running instruction) is never disrupted.
    case "INSTRUCTION_CANCEL": {
      const state = await getState();
      if (state.kind === "arming" && state.mode === "instruction") {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
      }
      return { ok: true };
    }
    // ── Popup: cancel ─────────────────────────────────────────────────
    case "CANCEL": {
      intentionalStop = true;
      const cancelState = await getState();
      const cancelTabId = cancelState.kind === "recording" && cancelState.mode === "instruction" ? cancelState.recorderTabId : cancelState.kind === "arming" && cancelState.mode === "instruction" ? cancelState.recorderTabId : void 0;
      const contentCancelTabId = cancelState.kind === "recording" && cancelState.contentRecorderTabId !== void 0 ? cancelState.contentRecorderTabId : cancelState.kind === "arming" && cancelState.contentRecorderTabId !== void 0 ? cancelState.contentRecorderTabId : void 0;
      if (cancelTabId !== void 0) {
        await sendControlWithRetry(
          () => chrome.tabs.sendMessage(cancelTabId, { type: "STOP_CAPTURE" }),
          "STOP_CAPTURE\u2192tab"
        );
      } else if (contentCancelTabId !== void 0) {
        await sendControlWithRetry(
          () => chrome.tabs.sendMessage(contentCancelTabId, {
            type: "STOP_CAPTURE"
          }),
          "STOP_CAPTURE\u2192tab"
        );
      } else {
        await sendControlWithRetry(
          () => sendToOffscreen({ type: "STOP_CAPTURE" }),
          "STOP_CAPTURE\u2192offscreen"
        );
      }
      await closeOffscreenDocument();
      if (cancelState.kind === "recording") {
        await abortUpload(cancelState.uploadId);
      }
      await setState({ kind: "idle" });
      updateBadge({ kind: "idle" });
      return { ok: true };
    }
    // ── Popup / content: get state ────────────────────────────────────
    case "GET_STATE": {
      return await getState();
    }
    // ── Content: Meet call started ────────────────────────────────────
    case "MEET_CALL_STARTED": {
      const settings = await getSettings();
      if (settings.autoRecordOnMeet) {
        return {
          autoRecord: true,
          countdownSec: settings.autoRecordCountdownSec
        };
      }
      return { autoRecord: false };
    }
    // ── Content: Meet call ended ──────────────────────────────────────
    case "MEET_CALL_ENDED": {
      const meetingId = getString(msg, "meetingId");
      const senderTabId = _sender.tab?.id;
      const state = await getState();
      if (state.kind === "recording" && state.mode === "meeting" && state.meetingId === meetingId && (senderTabId === void 0 || state.tabId === senderTabId) && Date.now() - state.startedAt >= MIN_MEET_RECORDING_MS_BEFORE_AUTO_STOP) {
        intentionalStop = true;
        let autoStopDelivered;
        if (state.contentRecorderTabId !== void 0) {
          autoStopDelivered = await sendControlWithRetry(
            () => chrome.tabs.sendMessage(state.contentRecorderTabId, {
              type: "STOP_CAPTURE"
            }),
            "STOP_CAPTURE\u2192tab"
          );
        } else {
          autoStopDelivered = await sendControlWithRetry(
            () => sendToOffscreen({ type: "STOP_CAPTURE" }),
            "STOP_CAPTURE\u2192offscreen"
          );
        }
        if (!autoStopDelivered) {
          await enqueueRecorder(() => finalizeRecording());
        }
      } else if (state.kind === "recording" && state.mode === "instruction" && state.meetingRequired === true && state.sourceTabId !== void 0 && senderTabId === state.sourceTabId && Date.now() - state.startedAt >= MIN_MEET_RECORDING_MS_BEFORE_AUTO_STOP) {
        promptStopOnMeetEnded();
      }
      return { ok: true };
    }
    // ── Content: user clicked "Record now" nudge ──────────────────────
    // FIX A (Codex v4): chrome.action.openPopup() gives NO guarantee of
    // granting activeTab/tabCapture — only a direct click on the extension
    // icon does. This handler therefore NEVER attempts tabCapture itself
    // (that used to fail silently into a client-less recording in the rare
    // case activeTab happened to still be granted from an unrelated earlier
    // icon click). It only opens the popup as a convenience; the guarantee
    // rests entirely on the user clicking "Record full-screen meeting" there.
    case "MEET_NUDGE_RECORD_NOW": {
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        try {
          if (typeof chrome.action?.openPopup === "function") {
            await chrome.action.openPopup().catch(() => {
              chrome.runtime.openOptionsPage();
            });
          } else {
            chrome.runtime.openOptionsPage();
          }
        } catch {
          chrome.runtime.openOptionsPage();
        }
        return { ok: false, error: "not signed in" };
      }
      try {
        if (typeof chrome.action?.openPopup === "function") {
          await chrome.action.openPopup();
        }
      } catch {
      }
      return { ok: true };
    }
    // Content: the in-page Meet nudge already obtained a getDisplayMedia()
    // stream from the real button gesture. Prepare SW state so its following
    // RECORDER_STARTED message initializes a meeting upload, not instruction.
    case "MEET_NUDGE_CAPTURE_READY": {
      const meetingId = getString(msg, "meetingId");
      const tabId = await resolveMeetSenderTabId(_sender);
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        try {
          if (typeof chrome.action?.openPopup === "function") {
            await chrome.action.openPopup().catch(() => {
              chrome.runtime.openOptionsPage();
            });
          } else {
            chrome.runtime.openOptionsPage();
          }
        } catch {
          chrome.runtime.openOptionsPage();
        }
        return { ok: false, error: "not signed in" };
      }
      if (tabId === void 0) {
        return { ok: false, error: "No Meet tab to record" };
      }
      await setState({
        kind: "arming",
        mode: "meeting",
        meetingId,
        tabId,
        contentRecorderTabId: tabId
      });
      return {
        ok: true,
        micEnabled: settings.micEnabled,
        micDeviceId: settings.micDeviceId
      };
    }
    case "MEET_NUDGE_LATER":
    case "MEET_NUDGE_DISMISS":
      return { ok: true };
    // ── Content: settings query ───────────────────────────────────────
    case "GET_SETTINGS": {
      const settings = await getSettings();
      return {
        autoRecordOnMeet: settings.autoRecordOnMeet,
        autoRecordCountdownSec: settings.autoRecordCountdownSec,
        soundEnabled: settings.soundEnabled
      };
    }
    // ── Recorder tab: request the source tab's audio (remote participants) ──
    // Minted here (SW) with consumerTabId = the recorder tab, so THAT tab can
    // consume it via getUserMedia(chromeMediaSource:"tab"). No "share system
    // audio" tick needed. Returns { streamId: null } when there is no usable
    // source tab (e.g. launched from a non-capturable page) — the recorder then
    // falls back to screen + mic. `required` mirrors meetingRequired and MUST
    // be preserved on every failure branch — the recorder page fails closed
    // (never starts / hard-stops) instead of silently dropping client audio
    // when required is true.
    case "REQUEST_TAB_AUDIO": {
      const st = await getState();
      const sourceTabId = st.kind === "arming" ? st.sourceTabId : void 0;
      const required = st.kind === "arming" && st.meetingRequired === true;
      const consumerTabId = _sender.tab?.id;
      const isCurrentRecorderTab = st.kind === "arming" && st.recorderTabId !== void 0 && consumerTabId === st.recorderTabId;
      if (sourceTabId === void 0 || consumerTabId === void 0 || !isCurrentRecorderTab) {
        return { streamId: null, required };
      }
      try {
        const sourceTab = await chrome.tabs.get(sourceTabId);
        if (!isMeetUrl(sourceTab.url)) {
          return { streamId: null, required };
        }
      } catch {
        return { streamId: null, required };
      }
      try {
        const streamId = await getTabMediaStreamId(sourceTabId, consumerTabId);
        return { streamId, required };
      } catch (err) {
        console.warn("[sw] tab-audio streamId failed:", err);
        return { streamId: null, required };
      }
    }
    // ── Recorder tab: mid-recording tab-audio degradation detected locally ──
    // The recorder page detected the tab-audio track/context degraded but did
    // NOT stop its own recorder (see recorder-page.ts handleTabAudioDegraded —
    // owner 2026-07-15: never stop, warn + auto-recover when possible). We
    // only notify + badge — NEVER set state to "error", which would make
    // finalizeRecording() bail (state.kind !== "recording").
    case "TAB_AUDIO_DEGRADED": {
      const cause = getString(msg, "cause");
      if (!intentionalStop && (cause === "muted" || cause === "suspended" || cause === "ended")) {
        notifyTabAudioDegraded(cause);
      }
      return { ok: true };
    }
    // ── Recorder tab: mid-recording tab-audio recovered (muted→unmuted, or
    // audioCtx resumed) ───────────────────────────────────────────────────
    case "TAB_AUDIO_RECOVERED": {
      if (!intentionalStop) await notifyTabAudioRecovered();
      return { ok: true };
    }
    // ── Offscreen: recorder started ───────────────────────────────────
    case "RECORDER_STARTED": {
      const mime = getString(msg, "mime") ?? "video/webm";
      const state = await getState();
      const mode = state.kind === "arming" ? state.mode : "instruction";
      const meetingId = state.kind === "arming" ? state.meetingId : void 0;
      const tabId = state.kind === "arming" ? state.tabId : void 0;
      const recorderTabId = state.kind === "arming" ? state.recorderTabId : void 0;
      const contentRecorderTabId = state.kind === "arming" ? state.contentRecorderTabId : void 0;
      const sourceTabId = state.kind === "arming" ? state.sourceTabId : void 0;
      const meetingRequired = state.kind === "arming" ? state.meetingRequired : void 0;
      let videoId;
      let uploadId;
      try {
        const result = await initializeUpload(mode, meetingId);
        videoId = result.videoId;
        uploadId = result.uploadId;
      } catch (err) {
        console.error("[sw] initializeUpload failed:", err);
        const errState = {
          kind: "error",
          reason: `Failed to initialize upload: ${err instanceof Error ? err.message : String(err)}`,
          recoverable: true
        };
        await setState(errState);
        updateBadge(errState);
        await closeOffscreenDocument().catch(() => {
        });
        return { ok: false, error: "initializeUpload failed" };
      }
      const nextState = {
        kind: "recording",
        mode,
        videoId,
        uploadId,
        startedAt: Date.now(),
        parts: [],
        nextPartNumber: 1,
        totalBytes: 0,
        uploadedBytes: 0,
        meetingId,
        tabId,
        mime,
        paused: false,
        pausedAccumMs: 0,
        recorderTabId,
        contentRecorderTabId,
        sourceTabId,
        meetingRequired
      };
      await setState(nextState);
      intentionalStop = false;
      tabAudioDegradedNotified = false;
      startKeepAlive();
      updateBadge(nextState);
      return { ok: true };
    }
    // ── Offscreen: data chunk ─────────────────────────────────────────
    case "RECORDER_CHUNK": {
      const raw = msg.chunk;
      const index = getNumber(msg, "index") ?? 0;
      const mime = getString(msg, "mime") ?? "video/webm";
      if (raw && Array.isArray(raw) && raw.length > 0) {
        await enqueueRecorder(
          () => handleChunk(new Uint8Array(raw).buffer, index, mime)
        );
      }
      return { ok: true };
    }
    // ── Offscreen: recorder stopped ───────────────────────────────────
    case "RECORDER_STOPPED": {
      await enqueueRecorder(() => finalizeRecording());
      return { ok: true };
    }
    // ── Offscreen: recorder error ─────────────────────────────────────
    case "RECORDER_ERROR": {
      const error = getString(msg, "error") ?? "Unknown recorder error";
      await enqueueRecorder(async () => {
        const stateBefore = await getState();
        const wasRecording = stateBefore.kind === "recording";
        const previousVideoId = wasRecording ? stateBefore.videoId : void 0;
        const bytesBefore = wasRecording ? stateBefore.uploadedBytes : 0;
        stopKeepAlive();
        await closeOffscreenDocument().catch(() => {
        });
        if (wasRecording) {
          await finalizeUpload();
        }
        const stateAfter = await getState();
        if (stateAfter.kind === "complete") {
          updateBadge(stateAfter);
          chrome.notifications.create("recorder-error", {
            type: "basic",
            iconUrl: "icons/icon-128.png",
            title: "Recording error \u2014 saved",
            message: `A recording error occurred (${error}), but ${bytesBefore} bytes were salvaged and saved.`
          });
          return;
        }
        if (stateAfter.kind === "uploading") {
          updateBadge(stateAfter);
          chrome.notifications.create("recorder-error", {
            type: "basic",
            iconUrl: "icons/icon-128.png",
            title: "Recording error \u2014 retrying upload",
            message: `A recording error occurred (${error}); the upload is retrying in the background.`
          });
          return;
        }
        if (stateAfter.kind === "error") {
          updateBadge(stateAfter);
          chrome.notifications.create("recorder-error", {
            type: "basic",
            iconUrl: "icons/icon-128.png",
            title: "Recording error",
            message: stateAfter.reason
          });
          return;
        }
        const nextState = {
          kind: "error",
          reason: error,
          recoverable: true,
          previousVideoId
        };
        await setState(nextState);
        updateBadge(nextState);
        chrome.notifications.create("recorder-error", {
          type: "basic",
          iconUrl: "icons/icon-128.png",
          title: "Recording error",
          message: error
        });
      });
      return { ok: true };
    }
    // ── Popup: retry after error ──────────────────────────────────────
    case "RETRY": {
      const state = await getState();
      if (state.kind !== "error")
        return { ok: false, error: "not in error state" };
      await setState({ kind: "idle" });
      updateBadge({ kind: "idle" });
      return { ok: true };
    }
    // ── Options: save settings ────────────────────────────────────────
    case "SAVE_SETTINGS": {
      const settings = msg.settings;
      if (settings) {
        await setSettings(settings);
      }
      return { ok: true };
    }
    // ── Options: get all settings ─────────────────────────────────────
    case "GET_ALL_SETTINGS": {
      return await getSettings();
    }
    // ── Sign-in-with-Cap token from options page ──────────────────────
    case "CAP_EXTENSION_TOKEN": {
      const token = getString(msg, "token");
      const apiBaseUrl = getString(msg, "apiBaseUrl");
      if (token) {
        await setSettings({
          apiKey: token,
          ...apiBaseUrl ? { apiBaseUrl } : {}
        });
      }
      return { ok: true };
    }
    // ── Popup/Options: sign in via Chrome identity (robust OAuth) ──────
    // Runs launchWebAuthFlow in the SERVICE WORKER (not the popup, which can
    // close mid-flow). The web callback redirects to chrome.identity's
    // redirect URL with the freshly-minted token in the URL fragment; we
    // extract and persist it. No reliance on externally_connectable or any
    // web→extension messaging, so it works on any deploy URL and for any user.
    case "START_SIGNIN": {
      const settings = await getSettings();
      const baseUrl = settings.apiBaseUrl || DEFAULT_API_BASE_URL;
      const redirectUri = chrome.identity.getRedirectURL();
      const url = `${baseUrl}/extension/callback?redirect=${encodeURIComponent(
        redirectUri
      )}`;
      let responseUrl;
      try {
        responseUrl = await new Promise(
          (resolve, reject) => {
            chrome.identity.launchWebAuthFlow(
              { url, interactive: true },
              (r) => {
                if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
                } else {
                  resolve(r ?? void 0);
                }
              }
            );
          }
        );
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : "sign-in failed"
        };
      }
      if (!responseUrl) return { ok: false, error: "sign-in cancelled" };
      let signInToken;
      try {
        const hash = new URL(responseUrl).hash.replace(/^#/, "");
        signInToken = new URLSearchParams(hash).get("token") ?? void 0;
      } catch {
        signInToken = void 0;
      }
      if (!signInToken) return { ok: false, error: "no token returned" };
      await setSettings({ apiKey: signInToken, apiBaseUrl: baseUrl });
      return { ok: true };
    }
    default:
      return { ok: false, error: `unknown message type: ${type}` };
  }
}
chrome.runtime.onMessageExternal.addListener(
  (message, _sender, sendResponse) => {
    if (!isMessageBase(message)) {
      sendResponse({ ok: false });
      return false;
    }
    const msg = message;
    if (msg.type === "CAP_EXTENSION_TOKEN") {
      const token = getString(msg, "token");
      const apiBaseUrl = getString(msg, "apiBaseUrl");
      getSettings().then((settings) => {
        if (!isTrustedTokenSender(_sender.url, settings.apiBaseUrl)) {
          console.warn(
            "Rejected CAP_EXTENSION_TOKEN from untrusted origin:",
            _sender.url
          );
          sendResponse({ ok: false, error: "untrusted origin" });
          return;
        }
        if (apiBaseUrl) {
          const senderOrigin = originOf(_sender.url);
          const requestedOrigin = originOf(apiBaseUrl);
          if (!senderOrigin || !requestedOrigin || senderOrigin !== requestedOrigin) {
            console.warn(
              "Rejected CAP_EXTENSION_TOKEN: apiBaseUrl origin mismatch",
              { senderOrigin, requestedOrigin }
            );
            sendResponse({
              ok: false,
              error: "apiBaseUrl/origin mismatch"
            });
            return;
          }
        }
        setSettings({
          apiKey: token ?? "",
          ...apiBaseUrl ? { apiBaseUrl } : {}
        }).then(() => {
          chrome.runtime.sendMessage({ type: "CAP_EXTENSION_TOKEN", token, apiBaseUrl }).catch(() => {
          });
          sendResponse({ ok: true });
        });
      }).catch(() => {
        sendResponse({ ok: false, error: "settings read failed" });
      });
      return true;
    }
    sendResponse({ ok: false });
    return false;
  }
);
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    handleMessage(message, sender).then(sendResponse).catch((err) => {
      const msg = err instanceof Error ? err.message : String(err);
      sendResponse({ ok: false, error: msg });
    });
    return true;
  }
);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (isKeepAliveAlarm(alarm.name)) {
    chrome.storage.local.get("capExtState");
  }
  if (isRetryAlarm(alarm.name)) {
    enqueueRecorder(() => retryPendingUploads()).catch(() => {
    });
  }
});
chrome.runtime.onStartup.addListener(async () => {
  const state = await getState();
  if (state.kind === "recording") {
    chrome.notifications.create("recording-interrupted", {
      type: "basic",
      iconUrl: "icons/icon-128.png",
      title: "Recording interrupted",
      message: "The browser restarted during recording. Uploading what was captured..."
    });
    const nextState = {
      kind: "uploading",
      videoId: state.videoId,
      uploadId: state.uploadId,
      parts: state.parts,
      totalBytes: state.totalBytes,
      uploadedBytes: state.uploadedBytes
    };
    await setState(nextState);
    updateBadge(nextState);
  }
  if (state.kind === "recording" || state.kind === "uploading") {
    startKeepAlive();
    await enqueueRecorder(() => finalizeUpload());
  } else if (state.kind === "finishing") {
    const resumed = await resumeInterruptedFinishing(
      state.videoId,
      state.uploadId,
      state.parts
    );
    const nextState = {
      kind: "error",
      reason: resumed ? "The browser restarted while finishing an upload \u2014 we're completing it in the background. You can start a new recording." : "The browser restarted while finishing an upload. Check your dashboard \u2014 the recording may have completed; otherwise please re-record.",
      recoverable: true,
      previousVideoId: state.videoId
    };
    await setState(nextState);
    updateBadge(nextState);
  }
  await enqueueRecorder(() => retryPendingUploads());
});
chrome.runtime.onInstalled.addListener(async () => {
  const state = await getState();
  updateBadge(state);
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (state.kind === "arming" && state.mode === "instruction" && state.recorderTabId === tabId) {
    await setState({ kind: "idle" });
    updateBadge({ kind: "idle" });
  } else if (state.kind === "recording" && state.mode === "instruction" && state.recorderTabId === tabId) {
    await enqueueRecorder(() => finalizeRecording()).catch(() => {
    });
  }
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (state.kind === "arming" && state.mode === "meeting" && state.contentRecorderTabId === tabId) {
    await setState({ kind: "idle" });
    updateBadge({ kind: "idle" });
  } else if (state.kind === "recording" && state.mode === "meeting" && state.contentRecorderTabId === tabId) {
    await enqueueRecorder(() => finalizeRecording()).catch(() => {
    });
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  handleSourceTabLost(tabId).catch(() => {
  });
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url === void 0 || isMeetUrl(changeInfo.url)) return;
  handleSourceTabLost(tabId).catch(() => {
  });
});
chrome.notifications.onButtonClicked.addListener((notifId, btnIdx) => {
  if (notifId !== MEET_ENDED_PROMPT_ID) return;
  chrome.notifications.clear(MEET_ENDED_PROMPT_ID);
  if (btnIdx === 0) stopInstructionDeliberate().catch(() => {
  });
});
if (chrome.tabCapture?.onStatusChanged) {
  chrome.tabCapture.onStatusChanged.addListener((info) => {
    if (intentionalStop) return;
    if (info.status !== "stopped" && info.status !== "error") return;
    console.warn("[sw] tabCapture.onStatusChanged (advisory only):", info);
  });
}
//# sourceMappingURL=background.js.map
